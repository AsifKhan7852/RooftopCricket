import React from 'react';
import { useLocation } from 'react-router-dom';
import './Register_Terms.css';
import arrow from '../Images/arrow.png';
import img1 from '../Images/SuperAdminBody.jpg';

export default function Register_Terms(props) {
    const location = useLocation();
    const { cart = [] } = location.state || {}; // Receiving cart data

    // LocalStorage se RooftopId aur RegisteredUserEmail uthana
    const storedUser = JSON.parse(localStorage.getItem("User")) || {};
    const rooftopId = localStorage.getItem("RooftopId") || "0"; // Default 0 agar na mile
    const registeredUserEmail = storedUser.Email || "unknown@example.com";
    const token = storedUser.Token || "";

    console.log("Received Cart Data:", cart);
    console.log("RooftopId:", rooftopId);
    console.log("RegisteredUserEmail:", registeredUserEmail);

    const handleProceedToPayment = () => {
        if (cart.length === 0) {
            alert("Please select at least one slot before proceeding.");
            return;
        }

        const bookingData = {
            RooftopId: parseInt(rooftopId), // Ensure it's an integer
            RegisteredUserEmail: registeredUserEmail,
            Slots: cart.map(slot => ({
                SlotId: slot.slotId,
                StartTime: slot.startTime,
                EndTime: slot.endTime,
                Date: slot.slotDate
            }))
        };

        console.log("Sending Data to API:", bookingData);

        fetch(`${props.ngrok_url}/api/Booking/bookSlots`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${token}`
            },
            body: JSON.stringify(bookingData)
        })
            .then(response => response.json())
            .then(data => {
                console.log("API Response:", data);

                if (data.available) {
                    console.log("Success Message:", data.available);
                    alert(`Booking successful! Message from backend: ${data.available}`);
                } else if (data.notAvailable) {
                    console.log("Failure Message:", data.notAvailable);
                    alert(`Booking failed: ${data.notAvailable}`);
                } else {
                    console.log("Unexpected Response:", data);
                    alert("Unexpected response from server.");
                }
            })
            .catch(error => {
                console.error("API Error:", error);
                alert("Booking failed. Please try again.");
            });
    };

    return (
        <div className='register_terms'>
            <div className="register_term_head">
                <img src={arrow} alt="" />
                <h4>Terms & Conditions</h4>
            </div>
            <div className="register_term_subhead">
                <strong>For a Cricket Rooftop booking system, the terms and conditions might include the following points:</strong>
            </div>

            <div className="register_term_body">
                <div className="register_term_text">
                    <div className="register_term_text1">
                        <h4>1. BOOKING POLICY</h4>
                        <p>.Reservation should be made in advance.</p>
                        <p>.Full payment or deposit required upon booking.</p>
                    </div>

                    <div className="register_term_text1">
                        <h4>2. CANCELLATION & REFUND</h4>
                        <p>.Cancellations must be made at least 24-48 hours prior to the booking time for a refund.</p>
                        <p>.Late cancellations may not be eligible for a refund.</p>
                    </div>

                    <div className="register_term_text1">
                        <h4>3. USER RESPONSIBILITIES</h4>
                        <p>.Users are responsible for their behavior on the rooftop.</p>
                        <p>.Any damage to the facilities may result in a fine.</p>
                    </div>

                    <div className="register_term_text1">
                        <h4>4. HEALTH & SAFETY</h4>
                        <p>.Players must follow all safety guidelines and use proper equipment.</p>
                        <p>.The venue is not liable for personal injuries or accidents.</p>
                    </div>

                    <div className="register_term_text1">
                        <h4>5. WEATHER POLICY</h4>
                        <p>.In case of adverse weather, the management may reschedule the booking or offer a refund.</p>
                    </div>

                    <div className="register_term_text1">
                        <h4>6. TIME LIMITS</h4>
                        <p>.Users must vacate the premises promptly after their booked time slot.</p>
                    </div>
                </div>
                <div className="register_term_img">
                    <img src={img1} alt="" />
                </div>
            </div>

            <div className="register_term_btn">
                <button onClick={handleProceedToPayment}>Proceed to payment</button>
                <button>Cancel</button>
            </div>
        </div>
    );
}
