import React from 'react';
import './Register_Forget_Password.css';
import rolepic from '../Images/rolepic.png'; // make sure this path is correct

export default function Register_Forget_Password() {
    return (
        <div className="forgot-password-container">
            <div className="form-section">
                <h2>Forgot Password?</h2>
                <p>Please Enter your email to reset the password</p>
                <label>Email address</label>
                <input
                    type="email"
                    placeholder="Enter your email"
                    className="email-input"
                />
                <button className="reset-button">Reset Password</button>
            </div>
            <div className="image-section">
                <img src={rolepic} alt="Cricket Player" />
            </div>
        </div>
    );
}
