import React, { useState } from "react";
import "./Register_Booking_Update.css";

export default function Register_Booking_Update({ booking, onClose, onUpdateSuccess, ngrok_url, endpointName }) {
    const [formData, setFormData] = useState({
        date: booking.slotDate || "",
        startTime: booking.startTime || "",
        endTime: booking.endTime || "",
    });

    // 🔹 Input Field Change Handler
    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    // 🔹 Form Submit Handler
    const handleSubmit = async (e) => {
        e.preventDefault();

        try {
            const storedUser = JSON.parse(localStorage.getItem("User")) || {};
            const token = storedUser.Token || "";

            const updateUrl = `${ngrok_url}/api/Booking/${endpointName}Booking`;

            // 🔹 Create FormData
            const formDataToSend = new FormData();
            formDataToSend.append("BookingId", booking.bookingId);
            formDataToSend.append("Date", formData.date);
            formDataToSend.append("StartTime", formData.startTime);
            formDataToSend.append("EndTime", formData.endTime);

            console.log("📢 Sending Request To:", updateUrl);
            console.log("📤 FormData Sent:", Object.fromEntries(formDataToSend));

            // 🔹 Send PUT Request
            const response = await fetch(updateUrl, {
                method: "PUT",
                headers: {
                    "Authorization": `Bearer ${token}`,
                    "ngrok-skip-browser-warning": "true",  // ✅ NGROK WARNING SKIP
                    // "Accept": "application/json",  // ✅ Ensure JSON response
                },
                body: formDataToSend,
            });

            const responseData = await response.text();  // ✅ Handle text response


            console.log("✅ Response Status:", response.status);
            console.log("✅ Response Data:", responseData);

            if (!response.ok) {
                throw new Error(responseData || `Failed to ${endpointName} booking.`);
            }

            alert(`✅ Booking ${endpointName} successfully!`);
            onUpdateSuccess(); // Refresh parent component
            onClose(); // Close modal
        } catch (error) {
            console.error(`❌ ${endpointName} failed:`, error.message);
            alert(`Failed to ${endpointName} booking. Please try again.`);
        }
    };

    return (
        <div className="modal-overlay">
            <div className="modal-content">
                <span className="close-btn" onClick={onClose}>&times;</span>
                <h2>Update Booking</h2>
                <form onSubmit={handleSubmit}>
                    <div className="form-group">
                        <label>Date:</label>
                        <input type="date" name="date" value={formData.date} onChange={handleChange} required />
                    </div>
                    <div className="form-group">
                        <label>Start Time:</label>
                        <input type="time" name="startTime" value={formData.startTime} onChange={handleChange} required />
                    </div>
                    <div className="form-group">
                        <label>End Time:</label>
                        <input type="time" name="endTime" value={formData.endTime} onChange={handleChange} required />
                    </div>
                    <button type="submit">Update Booking</button>
                </form>
            </div>
        </div>
    );
}
