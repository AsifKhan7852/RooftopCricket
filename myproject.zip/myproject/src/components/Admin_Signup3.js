// Admin_Signup3.jsx
import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import './Admin_Signup3.css';
import img1 from '../Images/admin_body.png';
import arrow from '../Images/arrow.png';

export default function Admin_Signup3({ ngrok_url }) {
    const navigate = useNavigate();
    const { state } = useLocation();
    const { adminData, rooftopData, images } = state || {};

    const [startTime, setStartTime] = useState('');
    const [endTime, setEndTime] = useState('');
    const [pitches, setPitches] = useState(1);
    const [price, setPrice] = useState('');

    async function handleSubmit(e) {
        e.preventDefault();
        const formData = new FormData();

        Object.entries(adminData).forEach(([key, value]) => {
            formData.append(`Admin.${key}`, value);
        });

        const rooftopPayload = {
            ...rooftopData,
            StartTime: startTime,
            EndTime: endTime,
            NumberOfPitches: pitches,
            PricePerHour: price,
        };

        Object.entries(rooftopPayload).forEach(([key, value]) => {
            formData.append(`Rooftop.${key}`, value);
        });

        images.forEach(file => formData.append('Rooftop.Images', file));

        const res = await fetch(`${ngrok_url}/api/RooftopAdmin/addAdminWithRooftop`, {
            method: 'POST',
            body: formData,
        });

        if (res.ok) {
            navigate('/admin_signup3');
        } else {
            alert('Error during signup. Please try again.');
        }
    }

    return (
        <div className='admin_signup3'>
            <div className="admin_body_tex_signup3">
                <img
                    src={arrow}
                    alt="back"
                    onClick={() => navigate('/admin_signup1', { state: { adminData, rooftopData, images } })}
                />
                <h2>Schedule & Pricing</h2>
                <p>Process</p>
                <form className='admin_form_signup3' onSubmit={handleSubmit}>
                    <label>Time Schedule</label><br />
                    <input value={startTime} onChange={e => setStartTime(e.target.value)} placeholder='Opening' size={24} required />
                    <input value={endTime} onChange={e => setEndTime(e.target.value)} placeholder='Closing' size={24.5} required /><br /><br />
                    <label>Number of pitches</label><br />
                    <input type='number' value={pitches} onChange={e => setPitches(e.target.value)} style={{ width: '30.5vw' }} required /><br /><br />
                    <label>Price per hour</label><br />
                    <input value={price} onChange={e => setPrice(e.target.value)} placeholder='Enter price per hour' size={55} required /><br /><br />
                    <button type='submit'>Submit</button>
                </form>
                <div className='admin_or_signup3'>
                    <hr /><h4>or</h4><hr />
                </div>
                <div className="admin_signin_signup3">
                    <p>Have an account?</p><a href="#">Sign in</a>
                </div>
            </div>
            <div className="admin_body_im_signup3">
                <img src={img1} alt="bg" />
            </div>
        </div>
    );
}
