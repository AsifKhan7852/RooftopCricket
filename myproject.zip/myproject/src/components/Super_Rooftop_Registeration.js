import React, { useEffect, useState } from 'react';
import './Super_Rooftop_Registeration.css';
import arrow from '../Images/arrow.png';
import search from '../Images/search.png';
import img1 from '../Images/admin_body.png';
import { Link } from 'react-router-dom';


export default function Super_Rooftop_Registeration(props) {
    const [rooftops, setRooftops] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [city, setCity] = useState('');
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    // Get token from localStorage
    const token = localStorage.getItem('superadmin') || null;

    const fetchRooftops = async (rooftopName = '', city = '') => {
        if (!token) {
            window.location.href = '/super-admin-login';
            return;
        }

        setLoading(true);
        setError(null);

        // Build query string with optional parameters
        const queryParams = new URLSearchParams({ status: 'Pending' });
        if (rooftopName) queryParams.append('rooftopName', rooftopName);
        if (city) queryParams.append('city', city);

        try {
            const response = await fetch(
                `${props.ngrok_url}/api/Rooftop/fetchRooftopWithFilters?${queryParams.toString()}`,
                {
                    headers: {
                        'ngrok-skip-browser-warning': 'true',
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${token}`,
                    },
                }
            );

            if (!response.ok) {
                if (response.status === 401) {
                    localStorage.removeItem('superadmin');
                    window.location.href = '/super-admin-login';
                }
                throw new Error(`Request failed with status ${response.status}`);
            }

            const data = await response.json();
            setRooftops(data);
        } catch (error) {
            console.error('Failed to fetch rooftops:', error);
            setError(error.message);
        } finally {
            setLoading(false);
        }
    };

    const handleAccept = async (email) => {
        if (!token) {
            window.location.href = '/super-admin-login';
            return;
        }

        if (!window.confirm('Are you sure you want to accept this rooftop?')) {
            return;
        }

        try {
            const response = await fetch(
                `${props.ngrok_url}/api/SuperAdmin/RegisterRooftopAdmin/${encodeURIComponent(email)}`,
                {
                    method: 'POST',
                    headers: {
                        'ngrok-skip-browser-warning': 'true',
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${token}`,
                    },
                }
            );

            if (!response.ok) {
                if (response.status === 401) {
                    localStorage.removeItem('superadmin');
                    window.location.href = '/super-admin-login';
                }
                throw new Error('Failed to accept rooftop');
            }

            const result = await response.text();
            alert(result); // Show success message
            fetchRooftops(searchTerm, city); // Refresh with current filters
        } catch (error) {
            console.error('Error accepting rooftop:', error);
            alert(error.message);
        }
    };

    const handleReject = async (email) => {
        if (!token) {
            window.location.href = '/super-admin-login';
            return;
        }

        if (!window.confirm('Are you sure you want to reject this rooftop?')) {
            return;
        }

        try {
            const response = await fetch(
                `${props.ngrok_url}/api/UsersManagement/deleteAdmin/${encodeURIComponent(email)}`,
                {
                    method: 'DELETE',
                    headers: {
                        'ngrok-skip-browser-warning': 'true',
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${token}`,
                    },
                }
            );

            if (!response.ok) {
                if (response.status === 401) {
                    localStorage.removeItem('superadmin');
                    window.location.href = '/super-admin-login';
                }
                throw new Error('Failed to reject rooftop');
            }

            const result = await response.text();
            alert(result); // Show success message
            fetchRooftops(searchTerm, city); // Refresh with current filters
        } catch (error) {
            console.error('Error rejecting rooftop:', error);
            alert(error.message);
        }
    };

    useEffect(() => {
        if (token) {
            fetchRooftops(); // Initial fetch without filters
        } else {
            window.location.href = '/super-admin-login';
        }
    }, [token]);

    const handleSearchInput = (e) => {
        setSearchTerm(e.target.value);
    };

    const handleSearchButton = () => {
        fetchRooftops(searchTerm, city); // Fetch with current filters
    };

    const handleCityChange = (e) => {
        const selectedCity = e.target.value;
        setCity(selectedCity);
        fetchRooftops(searchTerm, selectedCity); // Fetch with updated city
    };

    return (
        <div className='s_manage_rooftop_reg'>
            <div className="s_manageroof_reg_head">
                <img src={arrow} alt="Back" onClick={() => window.history.back()} />
                <h4>Rooftop Management</h4>
            </div>

            <div className="s_manageroof_reg_body">
                <div className="s_manageroof_reg_text">
                    <div className="s_manageroof_reg_calender">
                        <div className="s_search_reg_main">
                            <input
                                className='s_manageroof_reg_calender_input'
                                type="text"
                                placeholder='Search Rooftop by Name'
                                value={searchTerm}
                                onChange={handleSearchInput}
                            />
                            <div className="s_manageroof_reg_search" onClick={handleSearchButton}>
                                <img src={search} alt="Search Icon" />
                            </div>
                        </div>

                        <select
                            name=""
                            id=""
                            className='s_manageroof_reg_active'
                            value={city}
                            onChange={handleCityChange}
                        >
                            <option value="">All Cities</option>
                            <option value="Rawalpindi">Rawalpindi</option>
                            <option value="Islamabad">Islamabad</option>
                            <option value="Lahore">Lahore</option>
                            <option value="Karachi">Karachi</option>
                        </select>
                    </div>

                    {loading && <div className="loading-message">Loading rooftops...</div>}
                    {error && <div className="error-message">{error}</div>}

                    <div className="s_manageroof_reg_table-container">
                        {rooftops.length > 0 ? (
                            <table className="s_manageroof_reg_custom-table">
                                <thead>
                                    <tr>
                                        <th>Rooftop Name</th>
                                        <th>City</th>
                                        <th>Owner Name</th>
                                        <th>Owner Contact No.</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {
                                        rooftops.map((rooftop, index) => (
                                            <tr key={index}>
                                                <td>{rooftop.rooftopName}</td>
                                                <td>{rooftop.location}</td>
                                                <td>{rooftop.name}</td>
                                                <td>{rooftop.phoneNo}</td>
                                            
                                                <td>
                                                    <Link
                                                        to={`/viewdetails/${rooftop.rooftopId}`}
                                                        state={{ rooftop: rooftop }}
                                                        className="s_manageroof_reg_button"
                                                    >
                                                        View Details
                                                    </Link>
                                                    <button
                                                        className="s_manageroof_reg_acceptbtn"
                                                        onClick={() => handleAccept(rooftop.adminEmail)}
                                                    >
                                                        Accept
                                                    </button>
                                                    <button
                                                        className='s_manageroof_reg_rejectbtn'
                                                        onClick={() => handleReject(rooftop.adminEmail)}
                                                    >
                                                        Reject
                                                    </button>
                                                </td>
                                            </tr>
                                        ))
                                    }
                                </tbody>
                            </table>
                        ) : (
                            !loading && <div className="no-results">No rooftops found</div>
                        )}
                    </div>
                </div>
                <div className="s_manageroof_reg_img">
                    {/* <img src={img1} alt="Admin Body" /> */}
                </div>
            </div>
        </div>
    );
}