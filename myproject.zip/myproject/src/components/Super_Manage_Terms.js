import React, { useState, useEffect } from 'react';
import './Super_Manage_Terms.css';
import arrow from '../Images/arrow.png';
import img1 from '../Images/SuperAdminBody.jpg';

export default function Super_Manage_Terms(props) {
  const [terms, setTerms] = useState([]);
  const [editingId, setEditingId] = useState(null);
  const [editedHeading, setEditedHeading] = useState('');
  const [editedContent, setEditedContent] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [newHeading, setNewHeading] = useState('');
  const [newContent, setNewContent] = useState('');

  // 🔃 Fetch Terms & Conditions from API
  useEffect(() => {
    fetch(`${props.ngrok_url}/api/Content/fetchTermsAndConditions`, {
      headers: {
        'ngrok-skip-browser-warning': 'true'
      }
    })
      .then(res => res.json())
      .then(data => {
        const formatted = data.map(item => ({
          id: item.id,
          heading: item.title,
          content: item.description.split('\n')
        }));
        setTerms(formatted);
      })
      .catch(err => console.error('Fetch error:', err));
  }, [props.ngrok_url]);

  const handleEdit = (term) => {
    setEditingId(term.id);
    setEditedHeading(term.heading);
    setEditedContent(term.content.join('\n'));
  };

  // ✏️ Update API
  const handleUpdate = async (id) => {
    try {
      const response = await fetch(`${props.ngrok_url}/api/Content/updateTermsAndConditions/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'ngrok-skip-browser-warning': 'true'
        },
        body: JSON.stringify({
          Title: editedHeading,
          Description: editedContent
        })
      });
      const text = await response.text();
      console.log('Update response:', text);
      const updatedTerms = terms.map(term =>
        term.id === id ? { ...term, heading: editedHeading, content: editedContent.split('\n') } : term
      );
      setTerms(updatedTerms);
      setEditingId(null);
    } catch (err) {
      console.error('Update error:', err);
    }
  };

  // ❌ Delete API
  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this term?')) {
      try {
        const response = await fetch(`${props.ngrok_url}/api/Content/deleteTermsAndConditions/${id}`, {
          method: 'DELETE',
          headers: {
            'ngrok-skip-browser-warning': 'true'
          }
        });
        const text = await response.text();
        console.log('Delete response:', text);
        setTerms(terms.filter(term => term.id !== id));
      } catch (err) {
        console.error('Delete error:', err);
      }
    }
  };

  const handleAddNew = () => {
    setShowAddForm(true);
  };

  // ➕ Add API
  const handleSaveNew = async () => {
    if (newHeading.trim() && newContent.trim()) {
      try {
        const response = await fetch(`${props.ngrok_url}/api/Content/createpolicy`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'ngrok-skip-browser-warning': 'true'
          },
          body: JSON.stringify({
            Title: newHeading,
            Description: newContent
          })
        });
        const resText = await response.text();
        console.log('Add response:', resText);

        const newTerm = {
          id: Date.now(), // Placeholder, ideally backend should return actual ID
          heading: newHeading.toUpperCase(),
          content: newContent.split('\n')
        };
        setTerms([...terms, newTerm]);
        setNewHeading('');
        setNewContent('');
        setShowAddForm(false);
      } catch (err) {
        console.error('Add error:', err);
      }
    }
  };

  const handleCancelAdd = () => {
    setNewHeading('');
    setNewContent('');
    setShowAddForm(false);
  };

  return (
    <div className='s_mange_term'>
      <div className="s_manageterm_head">
        <img src={arrow} alt="" onClick={() => window.history.back()} />
        <h4>Terms & Conditions Management</h4>
      </div>

      <div className="s_manageterm_body">
        <div className="s_term_main">
          <div className="s_term_head">
            <div className="s_term_h">Main Heading Text:</div>
            <div className="s_term_h_text">
              <h4>For Cricket Rooftop booking system,</h4>
              <h4>the Terms & Conditions include:</h4>
            </div>
          </div>

          <div className="s_term_body">
            <div className="s_term_h">Manage Terms & Conditions:</div>
            <div className="s_term_border">
              {terms.map((term, index) => (
                <div className="s_term_body_text" key={term.id}>
                  {editingId === term.id ? (
                    <>
                      <div className="s_term_question">
                        <input
                          type="text"
                          value={editedHeading}
                          onChange={(e) => setEditedHeading(e.target.value)}
                          className="term_input"
                        />
                      </div>
                      <div className="s_term_body_text1">
                        <textarea
                          value={editedContent}
                          onChange={(e) => setEditedContent(e.target.value)}
                          className="term_textarea"
                        />
                      </div>
                      <div className="term_buttons">
                        <button onClick={() => handleUpdate(term.id)} className="term_button update">Update</button>
                        <button onClick={() => setEditingId(null)} className="term_button cancel">Cancel</button>
                      </div>
                    </>
                  ) : (
                    <>
                      <div className="s_term_question">{index + 1}. {term.heading}</div>
                      <div className="s_term_body_text1">
                        {term.content.map((line, i) => (
                          <h4 key={i}>{line}</h4>
                        ))}
                      </div>
                      <div className="term_buttons">
                        <button onClick={() => handleEdit(term)} className="term_button edit">Edit</button>
                        <button onClick={() => handleDelete(term.id)} className="term_button delete">Delete</button>
                      </div>
                    </>
                  )}
                </div>
              ))}

              {showAddForm && (
                <div className="s_term_body_text">
                  <div className="s_term_question">
                    <input
                      type="text"
                      value={newHeading}
                      onChange={(e) => setNewHeading(e.target.value)}
                      placeholder="Enter new heading"
                      className="term_input"
                    />
                  </div>
                  <div className="s_term_body_text1">
                    <textarea
                      value={newContent}
                      onChange={(e) => setNewContent(e.target.value)}
                      placeholder="Enter content (separate points with new lines)"
                      className="term_textarea"
                    />
                  </div>
                  <div className="term_buttons">
                    <button onClick={handleSaveNew} className="term_button save">Save</button>
                    <button onClick={handleCancelAdd} className="term_button cancel">Cancel</button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="s_manageterm_img">
          <img src={img1} alt="" />
        </div>
      </div>

      <div className="s_term_btn">
        <button onClick={handleAddNew} className="term_button add">Add New</button>
      </div>
    </div>
  );
}
