import React, { useState } from 'react'
import './Admin_Home_Page.css'
import img2 from '../Images/nav_back.png'
import img3 from '../Images/admin_body.png'
import img4 from '../Images/bottom-bar2.png'
import img5 from '../Images/bottom-bar1.png'
import { useNavigate } from 'react-router-dom'

export default function Admin_Home_Page() {

    const [isDropdownOpen, setIsDropdownOpen] = useState(false);
    const navigate = useNavigate();

    // Handle logout
    const handleLogout = () => {
        // Clear localStorage
        localStorage.removeItem('adminsignin');
        // Redirect to admin_signup3 (login page)
        navigate('/admin_signup3');
    };

    return (
        <div className='amain'>

            <div className="admin_nav">
                <div className='anav_text'>

                    {/* Dropdown for Account Setting */}
                    <div className="adropdown">
                        <button onClick={() => setIsDropdownOpen(!isDropdownOpen)} className="adropbtn">
                            Manage Bookings ▼
                        </button>
                        {isDropdownOpen && (
                            <div className="adropdown-content">
                                <a href="/admin_manage_available">Manage available slots</a>
                                <a href="/admin_book_slot">Book a new slot</a>
                                <a href="/admin_manage_booked">Manage booked slots</a>
                            </div>
                        )}
                    </div>

                    <a href='/manage_customer'>Manage Customers</a>
                    <a href='/create_slot'>Create Slots</a>
                    <a href='/view_reports'>View Reports</a>

                    {/* Dropdown for Account Setting */}
                    <div className="a_a_dropdown">
                        <button onClick={() => setIsDropdownOpen(!isDropdownOpen)} className="a_a_dropbtn">
                            Account Setting ▼
                        </button>
                        {isDropdownOpen && (
                            <div className="a_a_dropdown-content">
                                <a href="/admin_edit_profile1">Edit Profile</a>
                                <a href="#" onClick={handleLogout}>Logout</a>
                            </div>
                        )}
                    </div>

                </div>
                <img src={img2} alt="" />
            </div>

            <div className="abody">
                <div className="abody_text">
                    <p>Game On, Above The City</p>
                    <p className='aexplore'>Rooftop Cricket</p>
                </div>
                <div className="abody_img">
                    <img src={img3} alt="" />
                </div>
            </div>

            <div className="avisitor_footor">
                <img src={img4} alt="" />
                <img src={img5} alt="" />
            </div>

        </div>
    )
}
