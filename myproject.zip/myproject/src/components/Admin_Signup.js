// Admin_Signup.jsx
import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import './Admin_Signup.css';
import img1 from '../Images/admin_body.png';
import arrow from '../Images/arrow.png';

export default function Admin_Signup() {
  const navigate = useNavigate();
  const { state } = useLocation();
  const prevAdminData = state?.adminData || {};

  const [name, setName] = useState(prevAdminData.Name || '');
  const [email, setEmail] = useState(prevAdminData.Email || '');
  const [phone, setPhone] = useState(prevAdminData.PhoneNo || '');
  const [cnic, setCnic] = useState(prevAdminData.CNIC || '');
  const [password, setPassword] = useState(prevAdminData.Password || '');

  function handleNext(e) {
    e.preventDefault();
    const adminData = { Name: name, Email: email, PhoneNo: phone, CNIC: cnic, Password: password };
    navigate('/admin_signup1', { state: { adminData } });
  }

  return (
    <div className='admin_signup'>
      <div className="admin_body_tex_signup">
        <img src={arrow} alt="back" onClick={() => navigate(-1)} />
        <h2>Personal Information</h2>
        <p>Process</p>
        <form className='admin_form_signup' onSubmit={handleNext}>
          <label>Name</label><br />
          <input value={name} onChange={e => setName(e.target.value)} placeholder='Enter your name' size={55} required /><br /><br />
          <label>Email address</label><br />
          <input value={email} onChange={e => setEmail(e.target.value)} placeholder='Enter email address' size={55} required /><br /><br />
          <label>Phone number</label><br />
          <input value={phone} onChange={e => setPhone(e.target.value)} placeholder='Enter phone number' size={55} required /><br /><br />
          <label>CNIC</label><br />
          <input value={cnic} onChange={e => setCnic(e.target.value)} placeholder='Enter CNIC' size={55} required /><br /><br />
          <label>Password</label><br />
          <input type='password' value={password} onChange={e => setPassword(e.target.value)} placeholder='Enter password' size={55} required /><br /><br />
          <button type='submit'>Next</button>
        </form>
        <div className='admin_or_signup'>
          <hr /><h4>or</h4><hr />
        </div>
        <div className="admin_signin_signup">
          <p>Have an account?</p><a href="#">Sign in</a>
        </div>
      </div>
      <div className="admin_body_im_signup">
        <img src={img1} alt="bg" />
      </div>
    </div>
  );
}
