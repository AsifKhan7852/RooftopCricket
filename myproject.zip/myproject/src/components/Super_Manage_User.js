import React, { useEffect, useState } from 'react';
import './Super_Manage_User.css';
import arrow from '../Images/arrow.png';
import search from '../Images/search.png';
import img1 from '../Images/admin_body.png';

export default function Super_Manage_User(props) {
    const [customers, setCustomers] = useState([]);
    const [status, setStatus] = useState('Active');
    const [searchTerm, setSearchTerm] = useState('');
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    // Get token from localStorage
    const token = localStorage.getItem('superadmin') || null;

    const fetchCustomers = async (status) => {
        if (!token) {
            window.location.href = '/super-admin-login';
            return;
        }

        setLoading(true);
        setError(null);

        try {
            const response = await fetch(
                `${props.ngrok_url}/api/UsersManagement/customers/byRooftop?status=${status}`,
                {
                    headers: {
                        'ngrok-skip-browser-warning': 'true',
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${token}`,
                    },
                }
            );

            if (!response.ok) {
                if (response.status === 401) {
                    localStorage.removeItem('superadmin');
                    window.location.href = '/super-admin-login';
                }
                throw new Error(`Request failed with status ${response.status}`);
            }

            const data = await response.json();
            setCustomers(data);
        } catch (error) {
            console.error('Failed to fetch customers:', error);
            setError(error.message);
        } finally {
            setLoading(false);
        }
    };

    const handleBlockUnblock = async (email) => {
        if (!token) {
            window.location.href = '/super-admin-login';
            return;
        }

        const shouldBlock = status === 'Active';
        const action = shouldBlock ? 'block' : 'unblock';

        if (!window.confirm(`Are you sure you want to ${action} this user?`)) {
            return;
        }

        try {
            const response = await fetch(
                `${props.ngrok_url}/api/UsersManagement/blockUnblockRegisteredUser/${encodeURIComponent(email)}?block=${shouldBlock}`,
                {
                    method: 'POST',
                    headers: {
                        'ngrok-skip-browser-warning': 'true',
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${token}`,
                    },
                }
            );

            if (!response.ok) {
                if (response.status === 401) {
                    localStorage.removeItem('superadmin');
                    window.location.href = '/super-admin-login';
                }
                throw new Error(`Failed to ${action} user`);
            }

            const result = await response.text();
            alert(result); // Show success message
            fetchCustomers(status); // Refresh the list
        } catch (error) {
            console.error(`Error ${action}ing user:`, error);
            alert(error.message);
        }
    };

    const handleDelete = async (userid) => {
        if (!token) {
            window.location.href = '/super-admin-login';
            return;
        }

        if (!window.confirm('Are you sure you want to delete this user?')) {
            return;
        }

        try {
            const response = await fetch(
                `${props.ngrok_url}/api/RegisteredUser/delete/${userid}`,
                {
                    method: 'DELETE',
                    headers: {
                        'ngrok-skip-browser-warning': 'true',
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${token}`,
                    },
                }
            );

            if (!response.ok) {
                if (response.status === 401) {
                    localStorage.removeItem('superadmin');
                    window.location.href = '/super-admin-login';
                }
                throw new Error('Failed to delete user');
            }

            const result = await response.text();
            alert(result); // Show success message
            fetchCustomers(status); // Refresh the list
        } catch (error) {
            console.error('Error deleting user:', error);
            alert(error.message);
        }
    };

    useEffect(() => {
        if (token) {
            fetchCustomers(status);
        } else {
            window.location.href = '/super-admin-login';
        }
    }, [status, token]);

    const handleStatusChange = (e) => {
        setStatus(e.target.value);
    };

    const handleSearch = (e) => {
        setSearchTerm(e.target.value);
    };

    const filteredCustomers = customers.filter((customer) =>
        customer.phoneNo.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div className="s_mange_user">
            <div className="s_manageuser_head">
                <img src={arrow} alt="Back" onClick={() => window.history.back()} />
                <h4>Users Management</h4>
            </div>

            <div className="s_manageuser_body">
                <div className="s_manageuser_text">
                    <div className="s_manageuser_calender">
                        <div className="s_user_search_main">
                            <input
                                className="s_manageuser_calender_input"
                                type="text"
                                placeholder="Search by Phone no"
                                value={searchTerm}
                                onChange={handleSearch}
                            />
                            <div className="s_manageuser_search">
                                <img src={search} alt="Search Icon" />
                            </div>
                        </div>

                        <select
                            name=""
                            id=""
                            className="s_manageuser_active"
                            value={status}
                            onChange={handleStatusChange}
                        >
                            <option value="Active">Active</option>
                            <option value="Blocked">Blocked</option>
                        </select>
                    </div>

                    {loading && <div className="loading-message">Loading users...</div>}
                    {error && <div className="error-message">{error}</div>}

                    <div className="s_manageuser_table-container">
                        {filteredCustomers.length > 0 ? (
                            <table className="s_manageuser_custom-table">
                                <thead>
                                    <tr>
                                        <th>User Email</th>
                                        <th>Phone no.</th>
                                        <th>Successful Booking</th>
                                        <th>Canceled Booking</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {filteredCustomers.map((customer, index) => (
                                        <tr key={index}>
                                            <td>{customer.email}</td>
                                            <td>{customer.phoneNo}</td>
                                            <td>{customer.successfulBookings || 0}</td>
                                            <td>{customer.cancelledBookings || 0}</td>
                                            <td>
                                                <button
                                                    className={`s_manageuser_button ${
                                                        status === 'Active' ? 'block-btn' : 'unblock-btn'
                                                    }`}
                                                    onClick={() => handleBlockUnblock(customer.email)}
                                                >
                                                    {status === 'Active' ? 'Block' : 'Unblock'}
                                                </button>
                                                <button
                                                    className="s_manageuser_deletebtn"
                                                    onClick={() => handleDelete(customer.userid)}
                                                >
                                                    Delete
                                                </button>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        ) : (
                            !loading && <div className="no-results">No users found</div>
                        )}
                    </div>
                </div>
                <div className="s_manageuser_img">
                    {/* <img src={img1} alt="Admin Body" /> */}
                </div>
            </div>
        </div>
    );
}