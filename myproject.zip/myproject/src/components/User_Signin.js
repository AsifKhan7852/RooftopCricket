import React, { useState } from "react";
import { useNavigate } from "react-router-dom"; // Import for navigation
import "./User_Signin.css";
import img1 from "../Images/vsignin.png";
import arrow from "../Images/arrow.png";

export default function User_Signin(props) {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [error, setError] = useState("");
    const navigate = useNavigate(); // Initialize navigation

    const handleLogin = async (e) => {
        e.preventDefault();
        setError(""); // Clear previous error

        const formData = new FormData();
        formData.append("Email", email);
        formData.append("Password", password);

        try {
            const response = await fetch(
                `${props.ngrok_url}/api/RegisteredUser/login`,
                {
                    method: "POST",
                    body: formData,
                }
            );

            if (!response.ok) {
                throw new Error("Invalid email or password"); // Force the error
            }

            const data = await response.json();

            console.log("Parsed response data:", data); // Debugging log

            if (Array.isArray(data) && data.length > 0) {
                const userData = data[0]; // Extract first object from array

                localStorage.setItem("User", JSON.stringify(userData));

                window.location.href = "/Register_Home_Page"; // Redirect
            } else {
                throw new Error("Unexpected response format");
            }
        } catch (err) {
            console.error("Fetch error:", err);
            setError(err.message || "Error connecting to server");
        }
    };


    return (
        <div className="vsignin">
            <div className="body_im">
                <img src={img1} alt="Signin" />
            </div>
            <div className="body_tex">
                <img src={arrow} alt="Arrow" />
                <h2>Welcome back!</h2>
                <p>Enter your Credentials to access your account</p>
                <br />
                <form className="vform" onSubmit={handleLogin}>
                    <label>Email address or Phone No</label>
                    <br />
                    <input
                        type="text"
                        placeholder="Enter your email address or phone number"
                        size={55}
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                    />
                    <br />
                    <br />
                    <label>Password</label>
                    <label className="forget">Forget password</label>
                    <br />
                    <input
                        type="password"
                        placeholder="Enter your password"
                        size={55}
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                    />
                    <br />
                    <br />
                    <button type="submit">Login</button>
                    <br />
                </form>

                {error && <p style={{ color: "red" }}>{error}</p>}

                <div className="or">
                    <hr />
                    <h4>or</h4>
                    <hr />
                </div>
                <div className="google">
                    <p>Sign in with Google</p>
                </div>
                <div className="signup">
                    <p>Don't have an account?</p>
                    <a href="#">Sign up</a>
                </div>
            </div>
        </div>
    );
}
