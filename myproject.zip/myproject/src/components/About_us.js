import React from 'react'
import './About_us.css'
import img1 from '../Images/vsignin.png'
import img2 from '../Images/admin_body.png'
import arrow from '../Images/arrow.png'


export default function About_us() {
    return (
        <div className='aboutus_main'>


            <div className="aboutus_main2">
                <div className='left_img'>
                    <img className='arrow' src={arrow} alt="" />
                    <img className='body_img' src={img1} alt="" />
                </div>
                <div className="aboutus_text">

                    <div className='mission'>
                        <h4>MISSION</h4>
                        <p>Connect cricket fans and promote rooftop cricket events.</p>
                    </div>
                    <div className='vision'>
                        <h4>VISION</h4>
                        <p>To build a vibrant community for rooftop cricket lovers.</p>
                    </div>
                    <div className='history'>
                        <h4>HISTORY</h4>
                        <p> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;We started the Rooftop Cricket website in early 2024, driven by our
                            <br />&nbsp;&nbsp; passion for the sport and the desire to create a unique platform for cricket
                            enthusiasts. The <br />&nbsp;&nbsp;&nbsp;&nbsp;idea was born during a casual rooftop match, where we
                            realized the need for a dedicated <br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; space to connect players,
                            share experiences, and organize events.<br /> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Since then, we've been working
                            to bring this vision to life, focusing on community <br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; engagement and
                            promoting rooftop cricket culture.</p>
                    </div>
                    <div className="achievment">
                        <h4>MILESTONES & ACHIEVMENTS</h4>
                    </div>

                </div>
                <div className="right_img">
                    <img src={img2} alt="" />
                </div>
            </div>
            <div className="cart">
                <div className="cart1">
                    <h4>&nbsp;&nbsp;&nbsp;&nbsp; Concept <br /> Development</h4>
                    <p>Finalized the website idea in early 2024</p>
                </div>
                <div className="cart2">
                    <h4>Website Launch</h4>
                    <p>&nbsp;&nbsp;Launched the beta version in June 2024</p>
                </div>
                <div className="cart3">
                    <h4>Community <br />Engagement</h4>
                    <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Gained 500+ <br />memebers in the first <br /> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;month.</p>
                </div>
                <div className="cart4">
                    <h4>Event Organization</h4>
                    <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Hosted our first <br />tournament in August <br /> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2024.</p>
                </div>
                <div className="cart5">
                    <h4>Partnerships</h4>
                    <p>Formed local brand <br />&nbsp;&nbsp;&nbsp;partnerships by <br />&nbsp; September 2024.</p>
                </div>
            </div>

            <div className="produced">
                <h4>PRODUCED BY</h4>
                <div className="name">
                    <div className="name1">
                        <img src={arrow} alt="" />
                        <p>HAMNA EMAN</p>
                    </div>
                    <div className="name1">
                        <img src={arrow} alt="" />
                        <p>Ahsan Tariq</p>
                    </div>
                    <div className="name1">
                        <img src={arrow} alt="" />
                        <p>Asif Khan</p>
                    </div>
                </div>




            </div>

        </div>
    )
}
