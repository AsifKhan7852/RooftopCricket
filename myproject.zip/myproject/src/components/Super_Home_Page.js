import React from 'react';
import { useNavigate } from 'react-router-dom';
import './Super_Home_Page.css';
import img2 from '../Images/nav_back.png';
import img3 from '../Images/SuperAdminBody.jpg';
import img4 from '../Images/bottom-bar2.png';
import img5 from '../Images/bottom-bar1.png';

export default function Super_Home_Page() {
    const navigate = useNavigate();

    const handleLogout = () => {
        // Remove all superadmin data from localStorage
        localStorage.removeItem('superadmin');
        // Navigate to super signin page
        navigate('/super_signin');
    };

    return (
        <div className='smain'>
            <div className="super_nav">
                <div className='snav_text'>
                    <a href='/manage_rooftop'>Manage Rooftops</a>
                    <a href='/manage_user'>Manage Users</a>
                    <a href='/manage_faq'>Manage FAQs</a>
                    <a href='/manage_term'>Manage Terms & Conditions</a>
                    <a href='/manage_rooftop_registeration'>Rooftop Registrations</a>
                    <a href='/super_signin' onClick={handleLogout}>Logout</a>
                </div>
                <img src={img2} alt="" />
            </div>

            <div className="sbody">
                <div className="sbody_text">
                    <p>Game On, Above The City</p>
                    <p className='sexplore'>Rooftop Cricket</p>
                </div>
                <div className="sbody_img">
                    <img src={img3} alt="" />
                </div>
            </div>

            <div className="svisitor_footor">
                <img src={img4} alt="" />
                <img src={img5} alt="" />
            </div>
        </div>
    );
}