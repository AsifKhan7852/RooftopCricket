// Admin_Signup2.jsx
import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import './Admin_Signup2.css';
import img1 from '../Images/admin_body.png';
import arrow from '../Images/arrow.png';

export default function Admin_Signup2() {
    const navigate = useNavigate();
    const { state } = useLocation();
    const { adminData, rooftopData: prevRooftopData = {}, images: prevImages = [] } = state || {};

    const [company, setCompany] = useState(prevRooftopData.RooftopName || '');
    const [address, setAddress] = useState(prevRooftopData.Address || '');
    const [locationInput, setLocationInput] = useState(prevRooftopData.Location || '');
    const [images, setImages] = useState(prevImages);

    function handleImageChange(e) {
        setImages(Array.from(e.target.files));
    }

    function handleNext(e) {
        e.preventDefault();
        const rooftopData = { RooftopName: company, Address: address, Location: locationInput };
        navigate('/admin_signup2', { state: { adminData, rooftopData, images } });
    }

    return (
        <div className='admin_signup2'>
            <div className="admin_body_tex_signup2">
                <img
                    src={arrow}
                    alt="back"
                    onClick={() => navigate('/admin_signup', { state: { adminData } })}
                />
                <h2>Rooftop Information</h2>
                <p>Process</p>
                <form className='admin_form_signup2' onSubmit={handleNext}>
                    <label>Company Name</label><br />
                    <input value={company} onChange={e => setCompany(e.target.value)} placeholder='Enter company name' size={55} required /><br /><br />
                    <label>Rooftop images/videos</label><br />
                    <input type="file" accept="image/*" multiple onChange={handleImageChange} /><br /><br />
                    <label>City</label><br />
                    <input value={address} onChange={e => setAddress(e.target.value)} placeholder='Enter address' size={55} required /><br /><br />
                    <label>Address</label><br />
                    <input value={locationInput} onChange={e => setLocationInput(e.target.value)} placeholder='Enter location' size={55} required /><br /><br />
                    <button type='submit'>Next</button>
                </form>
                <div className='admin_or_signup2'>
                    <hr /><h4>or</h4><hr />
                </div>
                <div className="admin_signin_signup2">
                    <p>Have an account?</p><a href="#">Sign in</a>
                </div>
            </div>
            <div className="admin_body_im_signup2">
                <img src={img1} alt="bg" />
            </div>
        </div>
    );
}
