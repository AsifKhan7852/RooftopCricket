import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import './Admin_Signup2.css';
import img1 from '../Images/admin_body.png';
import arrow from '../Images/arrow.png';

export default function Admin_Edit_Profile2() {
    const navigate = useNavigate();
    const { state } = useLocation();
    const { adminData } = state || {};
    const localData = JSON.parse(localStorage.getItem('adminsignin'));
    const rooftop = localData?.rooftops?.[0] || {};

    const [company, setCompany] = useState(rooftop.rooftopName || '');
    const [address, setAddress] = useState(rooftop.address || '');
    const [locationInput, setLocationInput] = useState(rooftop.location || '');
    const [images, setImages] = useState([]);

    const handleImageChange = (e) => {
        setImages(Array.from(e.target.files));
    };

    const handleNext = (e) => {
        e.preventDefault();
        const rooftopData = {
            RooftopName: company,
            Address: address,
            Location: locationInput,
        };
        navigate('/admin_edit_profile3', { state: { adminData, rooftopData, images } });
    };

    return (
        <div className='admin_signup2'>
            <div className="admin_body_tex_signup2">
                <img src={arrow} alt="back" onClick={() => navigate(-1)} />
                <h2>Rooftop Information</h2>
                <form className='admin_form_signup2' onSubmit={handleNext}>
                    <label>Company Name</label><br />
                    <input value={company} onChange={e => setCompany(e.target.value)} required /><br /><br />
                    <label>Rooftop images/videos</label><br />
                    <input type="file" accept="image" multiple onChange={handleImageChange} /><br /><br />
                    <label>City</label><br />
                    <input value={address} onChange={e => setAddress(e.target.value)} required /><br /><br />
                    <label>Address</label><br />
                    <input value={locationInput} onChange={e => setLocationInput(e.target.value)} required /><br /><br />
                    <button type='submit'>Next</button>
                </form>
            </div>
            <div className="admin_body_im_signup2">
                <img src={img1} alt="bg" />
            </div>
        </div>
    );
}