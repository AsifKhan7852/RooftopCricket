import React, { useState } from "react";
import { useNavigate } from "react-router-dom"; // Import useNavigate for redirection
import "./User_Signup.css";
import img1 from "../Images/user_signup.png";
import arrow from "../Images/arrow.png";

export default function User_Signup(props) {
    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [phoneNo, setPhoneNo] = useState("");
    const [password, setPassword] = useState("");
    const [error, setError] = useState("");
    const navigate = useNavigate(); // Initialize navigation

    const handleSignup = async (e) => {
        e.preventDefault();

        const formData = new FormData();
        formData.append("Name", name);
        formData.append("Email", email);
        formData.append("PhoneNo", phoneNo);
        formData.append("Password", password);

        try {
            const response = await fetch(
                `${props.ngrok_url}/api/RegisteredUser/signup`,
                {
                    method: "POST",
                    body: formData,
                }
            );

            const data = await response.json();

            if (response.ok) {
                alert("Signup Successful! Redirecting to login...");
                navigate("/user_signin"); // Redirect to login page
            } else {
                setError(data.message || "Signup failed. Try again.");
            }
        } catch (err) {
            setError("Error connecting to server");
        }
    };

    return (
        <div className="visitor_signup">
            <div className="visitor_body_tex_signup">
                <img src={arrow} alt="Arrow" />
                <h2>Get Started Now</h2>
                <form className="visitor_form_signup" onSubmit={handleSignup}>
                    <label>Name</label><br />
                    <input
                        type="text"
                        placeholder="Enter your name"
                        size={55}
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        required
                    /><br /><br />

                    <label>Email address</label><br />
                    <input
                        type="email"
                        placeholder="Enter your email address"
                        size={55}
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                    /><br /><br />

                    <label>Phone number</label><br />
                    <input
                        type="text"
                        placeholder="Enter your phone number"
                        size={55}
                        value={phoneNo}
                        onChange={(e) => setPhoneNo(e.target.value)}
                        required
                    /><br /><br />

                    <label>Password</label><br />
                    <input
                        type="password"
                        placeholder="Enter your password"
                        size={55}
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                    /><br /><br />

                    <input type="checkbox" required />
                    <label>I agree to the terms & policy</label><br /><br />

                    <button type="submit">Signup</button>
                </form>

                {error && <p style={{ color: "red" }}>{error}</p>}

                <div className="visitor_or_signup">
                    <hr />
                    <h4>or</h4>
                    <hr />
                </div>
                <div className="visitor_google_signup">
                    <p>Sign in with Google</p>
                </div>
                <div className="visitor_signin_signup">
                    <p>Have an account? </p>
                    <a href="/user_signin">Sign in</a>
                </div>
            </div>

            <div className="vistor_body_im_signup">
                <img src={img1} alt="Signup" />
            </div>
        </div>
    );
}
