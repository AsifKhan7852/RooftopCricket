import React from 'react'
import { Link} from 'react-router-dom'
import './Role_Selection_Signup.css'
import arrow from '../Images/arrow.png'
import back from '../Images/signinup.png'
import rolepic from '../Images/rolepic.png'


export default function Role_Selection_Signup() {
    return (
        <div className='signup_role'>
            <div className='signup_arrow'>
                <img src={arrow} alt="" />
            </div>
            <div className="signup_select">
                <div className="signup_heading">
                    <h4>Select role for Signup: </h4>
                </div>
                <div className="signup_role_selection">
                    <img src={back} alt="" />
                    <a href='/user_signup' >User</a>
                    <img src={back} alt="" />
                    <a href="/admin_signup">Admin</a>
        
                </div>
                <div className="signup_rolepic">
                <img src={rolepic} alt="" />
                </div>
            </div>
        </div>
    )
}
