import React from 'react'
import './Visitor_Home_Page.css'
import img1 from '../Images/aboutusbackground.png'
import img2 from '../Images/signinup.png'
import img3 from '../Images/visitorbody.jpg'
import img4 from '../Images/bottom-bar2.png'
import img5 from '../Images/bottom-bar1.png'
import img6 from '../Images/visitmore.png'


export default function Visitor_Home_Page() {
    return (
        <div className='main'>

            <div className="visit_nav">
                <div className="aboutus">
                    <img src={img1} alt="" />
                    <a href="/aboutus">About us</a>
                    <a href="/faq">View FAQ Sec</a>
                </div>
                <div className="signin">
                    <img src={img2} alt="" />
                    <a href="/visitor_signup">Sign up</a>
                    <a href="/visitor_signin">Sign in</a>
                </div>
            </div>

            <div className="body">
                <div className="body_text">
                    <p>Game On, Above The City</p>
                    <p className='explore'>Explore Rooftops</p>
                    <img src={img6} alt="" />
                </div>
                <div className="body_img">
                    <img src={img3} alt="" />
                </div>
            </div>

            <div className="visitor_footor">
                <img src={img4} alt="" />
                <a href="#">Help Center</a>
                <img src={img5} alt="" />
            </div>

        </div>
    )
}
