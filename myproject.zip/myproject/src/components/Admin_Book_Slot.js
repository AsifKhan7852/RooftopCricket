import React, { useEffect, useState } from 'react';
import './Admin_Book_Slot.css';
import arrow from '../Images/arrow.png';
import img1 from '../Images/admin_body.png';
import search from '../Images/search.png';

export default function Admin_Book_Slot(props) {
    const [slots, setSlots] = useState([]);
    const [selectedDate, setSelectedDate] = useState('');
    const [startTime, setStartTime] = useState('');
    const [endTime, setEndTime] = useState('');

    // Retrieve rooftopId from adminsignin object in localStorage
    const adminsignin = JSON.parse(localStorage.getItem('adminsignin')) || {};
    const rooftops = adminsignin.rooftops || [];
    const rooftopId = rooftops.length > 0 ? rooftops[0].rooftopId : null;

    const formatDate = (date) => {
        if (!date) return '';
        const [year, month, day] = date.split('-');
        return `${day}-${month}-${year}`;
    };

    // Fetch available slots
    const fetchSlots = async (date = '') => {
        if (!rooftopId) {
            console.error("Rooftop ID not found.");
            return;
        }

        try {
            let url = `${props.ngrok_url}/api/Slots/filterAvailableSlots?rooftopId=${rooftopId}`;
            if (date) url += `&date=${encodeURIComponent(formatDate(date))}`;

            const response = await fetch(url, {
                headers: {
                    'Content-Type': 'application/json',
                    'ngrok-skip-browser-warning': 'true'
                }
            });

            const data = await response.json();
            setSlots(data);
        } catch (error) {
            console.error("Error fetching slots:", error);
        }
    };

    // Handle slot search with filters
    const handleSearch = async () => {
        if (!selectedDate || !startTime) {
            alert("Please select a date and start time.");
            return;
        }

        try {
            let url = `${props.ngrok_url}/api/Slots/filterAvailableSlots?rooftopId=${rooftopId}`;
            if (selectedDate) url += `&date=${encodeURIComponent(formatDate(selectedDate))}`;
            if (startTime) url += `&startTime=${encodeURIComponent(startTime)}`;
            if (endTime) url += `&endTime=${encodeURIComponent(endTime)}`;

            const response = await fetch(url, {
                headers: {
                    'Content-Type': 'application/json',
                    'ngrok-skip-browser-warning': 'true'
                }
            });

            const data = await response.json();
            setSlots(data);
        } catch (error) {
            console.error("Error filtering slots:", error);
        }
    };

    useEffect(() => {
        fetchSlots();
    }, []);

    return (
        <div className='a_n_book'>
            <div className="a_b_head">
                <img src={arrow} alt="" />
                <h4>Slots Booking</h4>
            </div>

            <div className="a_b_body">
                <div className="a_b_text">
                    <div className="a_b_calender">
                        <input
                            className='a_b_calender_input'
                            type="date"
                            value={selectedDate}
                            onChange={(e) => setSelectedDate(e.target.value)}
                        />
                        <label>From: </label>
                        <input
                            className='a_b_calender_input'
                            type="time"
                            value={startTime}
                            onChange={(e) => setStartTime(e.target.value)}
                        />
                        <label>To:</label>
                        <input
                            className='a_b_calender_input'
                            type="time"
                            value={endTime}
                            onChange={(e) => setEndTime(e.target.value)}
                        />
                        <div className="a_search" onClick={handleSearch}>
                            <img src={search} alt="Search" />
                        </div>
                    </div>
                    <div className="a_b_table-container">
                        <table className="a_b_custom-table">
                            <thead>
                                <tr>
                                    <th>Slot Date</th>
                                    <th>Slot Time</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                {slots.length > 0 ? (
                                    slots.map((slot) => (
                                        <tr key={slot.slotId}>
                                            <td>{slot.date}</td>
                                            <td>{`${slot.startTime} - ${slot.endTime}`}</td>
                                            <td>
                                                <button className="a_b_button">Add to Cart</button>
                                            </td>
                                        </tr>
                                    ))
                                ) : (
                                    <tr>
                                        <td colSpan="3">No slots available</td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>
                <div className="a_b_img">
                    <img src={img1} alt="" />
                </div>
            </div>

            <div className="a_b_btn">
                <button className="proceed-button">Proceed</button>
            </div>
        </div>
    );
}