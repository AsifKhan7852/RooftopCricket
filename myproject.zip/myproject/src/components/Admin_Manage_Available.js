import React, { useEffect, useState } from 'react';
import './Admin_Manage_Available.css';
import arrow from '../Images/arrow.png';
import img1 from '../Images/admin_body.png';
import search from '../Images/search.png';

export default function Admin_Manage_Available({ngrok_url}) {
    const [slots, setSlots] = useState([]);
    const [selectedDate, setSelectedDate] = useState('');
    const [startTime, setStartTime] = useState('');
    const [endTime, setEndTime] = useState('');

    // Retrieve rooftopId and token from adminsignin object in localStorage
    const adminsignin = JSON.parse(localStorage.getItem('adminsignin')) || {};
    const rooftops = adminsignin.rooftops || [];
    const rooftopId = rooftops.length > 0 ? rooftops[0].rooftopId : null; // Assuming the first rooftop is used
    const token = adminsignin.token || '';

    const formatDate = (date) => {
        if (!date) return '';
        const [year, month, day] = date.split('-');
        return `${day}-${month}-${year}`;
    };

    // Fetch available slots
    const fetchSlots = async (date = '') => {
        if (!rooftopId) {
            console.error("Rooftop ID not found.");
            return;
        }

        try {
            let url = `${ngrok_url}/api/Slots/filterAvailableSlots?rooftopId=${rooftopId}`;
            if (date) url += `&date=${encodeURIComponent(formatDate(date))}`;

            console.log("Fetching URL:", url);

            const response = await fetch(url, {
                headers: {
                    'Content-Type': 'application/json',
                    'ngrok-skip-browser-warning': 'true',
                },
            });

            const text = await response.text();
            try {
                const data = JSON.parse(text);
                setSlots(data);
            } catch (jsonError) {
                console.error("API Response Error:", text);
            }
        } catch (error) {
            console.error("Error fetching data:", error);
        }
    };

    // Handle slot search with filters
    const handleSearch = async () => {
        if (!selectedDate || !startTime) {
            alert("Please select a date and start time.");
            return;
        }

        const now = new Date();
        const selectedDateTime = new Date(`${selectedDate}T${startTime}`);

        if (selectedDateTime <= now) {
            alert("Start time must be in the future.");
            return;
        }

        if (!rooftopId) {
            console.error("Rooftop ID not found.");
            return;
        }

        try {
            let url = `${ngrok_url}/api/Slots/filterAvailableSlots?rooftopId=${rooftopId}`;
            if (selectedDate) url += `&date=${encodeURIComponent(formatDate(selectedDate))}`;
            if (startTime) url += `&startTime=${encodeURIComponent(startTime)}`;
            if (endTime) url += `&endTime=${encodeURIComponent(endTime)}`;

            console.log("Fetching URL (Time Filter):", url);

            const response = await fetch(url, {
                headers: {
                    'Content-Type': 'application/json',
                    'ngrok-skip-browser-warning': 'true',
                },
            });

            const text = await response.text();
            console.log("Raw Response:", text);

            try {
                const data = JSON.parse(text);
                setSlots(data);
            } catch (jsonError) {
                console.error("API Response Error:", text);
            }
        } catch (error) {
            console.error("Error fetching data:", error);
        }
    };

    // Handle disabling a slot
    const handleDisableSlot = async (slot) => {
        if (!rooftopId || !token) {
            alert("Rooftop ID or token not found. Please log in again.");
            return;
        }

        const confirmDisable = window.confirm("Are you sure you want to disable this slot?");
        if (!confirmDisable) return;

        try {
            const response = await fetch(`${ngrok_url}/api/Slots/Disable_FreeSlots`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`,
                    'ngrok-skip-browser-warning': 'true',
                },
                body: JSON.stringify({
                    RooftopId: rooftopId,
                    Date: slot.date,
                    StartTime: slot.startTime,
                    EndTime: slot.endTime,
                    Disable:true
                }),
            });

            const text = await response.text();
            console.log("Disable Slot Response:", text);

            if (response.ok) {
                alert("Slot disabled successfully!");
                fetchSlots(selectedDate); // Refresh the slots after disabling
            } else {
                alert("Failed to disable slot. Please try again.");
            }
        } catch (error) {
            console.error("Error disabling slot:", error);
            alert("Error disabling slot. Please try again later.");
        }
    };

    useEffect(() => {
        fetchSlots(selectedDate);
    }, [selectedDate]);

    return (
        <div className='a_m_avail'>
            <div className="a_m_head">
                <img src={arrow} alt="" />
                <h4>Manage Available Slots</h4>
            </div>

            <div className="avail_body">
                <div className="avail_text">
                    <div className="avail_calender">
                        <input
                            className='avail_calender_input'
                            type="date"
                            value={selectedDate}
                            onChange={(e) => setSelectedDate(e.target.value)}
                        />
                        <label>From: </label>
                        <input
                            className='avail_calender_input'
                            type="time"
                            value={startTime}
                            onChange={(e) => setStartTime(e.target.value)}
                        />
                        <label>To:</label>
                        <input
                            className='avail_calender_input'
                            type="time"
                            value={endTime}
                            onChange={(e) => setEndTime(e.target.value)}
                        />
                        <div className="admin_avail_search" onClick={handleSearch}>
                            <img src={search} alt="Search" style={{ pointerEvents: "none" }} />
                        </div>
                    </div>
                    <div className="table-container">
                        <table className="custom-table">
                            <thead>
                                <tr>
                                    <th>Slot Date</th>
                                    <th>Slot Time</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                {slots.length > 0 ? (
                                    slots.map((slot) => (
                                        <tr key={slot.slotId}>
                                            <td>{slot.date}</td>
                                            <td>{`${slot.startTime} - ${slot.endTime}`}</td>
                                            <td>
                                                <button
                                                    className="disable-button"
                                                    onClick={() => handleDisableSlot(slot)}
                                                >
                                                    Disable
                                                </button>
                                            </td>
                                        </tr>
                                    ))
                                ) : (
                                    <tr>
                                        <td colSpan="3">No slots available</td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>
                <div className="avail_img">
                    <img src={img1} alt="" />
                </div>
            </div>
        </div>
    );
}