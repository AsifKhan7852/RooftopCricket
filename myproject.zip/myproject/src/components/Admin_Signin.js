import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom'; // Import useNavigate for redirection
import './Admin_Signin.css';
import img1 from '../Images/adminbody.jpg';
import arrow from '../Images/arrow.png';

export default function Admin_Signin({ngrok_url}) {
    const [emailOrPhone, setEmailOrPhone] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const navigate = useNavigate();

    // Function to handle form submission
    const handleLogin = async (e) => {
        e.preventDefault(); // Prevent default form submission

        // Validate inputs
        if (!emailOrPhone || !password) {
            setError("Please fill in all fields.");
            return;
        }

        try {
            const response = await fetch(`${ngrok_url}/api/RooftopAdmin/login`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'ngrok-skip-browser-warning': 'true', // Add this header to bypass ngrok warning
                },
                body: JSON.stringify({
                    Email: emailOrPhone, // Assuming the API expects "email" as the field
                    Password: password,
                }),
            });

            const data = await response.json();

            if (response.ok) {
                // Combine all data into a single object
                const adminsignin = {
                    admin: data.admin,
                    rooftops: data.rooftops,
                    token: data.token,
                };

                // Store the combined object in localStorage
                localStorage.setItem('adminsignin', JSON.stringify(adminsignin));

                // Redirect to admin home page
                navigate('/admin_home_page');
            } else {
                setError(data.message || "Login failed. Please check your credentials.");
            }
        } catch (error) {
            setError("Error connecting to the server. Please try again later.");
        }
    };

    return (
        <div className='asignin'>
            <div className="abody_im">
                <img src={img1} alt="" />
            </div>
            <div className="abody_tex">
                <img src={arrow} alt="" />
                <h2>Welcome back!</h2>
                <p>Enter your Credentials to access your account</p><br />
                <form onSubmit={handleLogin} className='avform'>
                    <label htmlFor="emailOrPhone">Email address or Phone No</label><br />
                    <input
                        type="text"
                        id="emailOrPhone"
                        placeholder='Enter your email address or phone number'
                        value={emailOrPhone}
                        onChange={(e) => setEmailOrPhone(e.target.value)}
                        size={55}
                    /><br /><br />
                    <label htmlFor="password">Password</label>
                    <label className='aforget'>forget password</label><br />
                    <input
                        type="password" // Use type="password" for password fields
                        id="password"
                        placeholder='Enter your password'
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        size={55}
                    /><br /><br />
                    {error && <p className="error-message">{error}</p>}
                    <button type="submit" className="login-button">Login</button>
                    <br />
                </form>

                <div className='aor'>
                    <hr />
                    <h4>or</h4>
                    <hr />
                </div>

                <div className="asignup">
                    <p>Don`t have an account? </p>
                    <a href="#">Sign up</a>
                </div>
            </div>
        </div>
    );
}