import React from 'react';
import './Admin_Signin_OTP.css';
import otpImage from '../Images/otpimage.png';
import otpHand from '../Images/otphand.png';

export default function Admin_Signin_OTP() {
    return (
        <div className="container">
            <div className="left-section">
                <img src={otpImage} alt="Cricket Player" />
            </div>
            <div className="right-section">
                <div className="otp-section">
                    <div className="back-arrow">←</div>
                    <div className="hand-image">
                        <img src={otpHand} alt="Hand with Phone" />
                    </div>
                    <div className="otp-content">
                        <h2>OTP Verification</h2>
                        <p>Enter the OTP sent to +92 313...14</p>
                        <div className="otp-inputs">
                            <input type="text" value="8" readOnly />
                            <input type="text" value="6" readOnly />
                            <input type="text" value="3" readOnly />
                            <input type="text" value="" placeholder=" " />
                        </div>
                        <button className="verify-button">Verify</button> <br />
                        <button className="resend-button">Resend OTP</button>
                    </div>

                </div>
            </div>
        </div>
    );
}