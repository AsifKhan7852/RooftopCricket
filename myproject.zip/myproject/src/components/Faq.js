import React, { useState, useEffect } from 'react';
import './Faq.css';
import img1 from '../Images/arrow.png';
import plus from '../Images/faq_plus.png';
import fimg from '../Images/SuperAdminBody.jpg';

export default function Faq({ngrok_url}) {
    // State to manage the visibility of answers
    const [visibleAnswers, setVisibleAnswers] = useState({});

    // State to store FAQ data fetched from the API
    const [faqData, setFaqData] = useState([]);

    // Function to toggle the visibility of an answer
    const toggleAnswer = (index) => {
        setVisibleAnswers((prev) => ({
            ...prev,
            [index]: !prev[index], // Toggle the visibility for the specific question
        }));
    };

    // Fetch FAQ data from the API
    useEffect(() => {
        const fetchFaqs = async () => {
            try {
                const response = await fetch(
                    `${ngrok_url}/api/Content/fetchfaqs`,
                    {
                        headers: {
                            'Content-Type': 'application/json',
                            'ngrok-skip-browser-warning': 'true', // Add this header to bypass ngrok warning
                        },
                    }
                );

                if (!response.ok) {
                    throw new Error('Failed to fetch FAQs');
                }

                const data = await response.json();
                setFaqData(data); // Set the fetched data to state
            } catch (error) {
                console.error('Error fetching FAQs:', error);
            }
        };

        fetchFaqs(); // Call the fetch function
    }, []); // Empty dependency array ensures this runs only once on mount

    return (
        <div className='user_faq'>
            <img src={img1} alt="" />
            <p className='user_faq_p'>Frequently Asked Questions</p>
            <div className="fbody">
                <div className="ftext">
                    {faqData.map((faq, index) => (
                        <div key={faq.id}>
                            <div className="faq-question" onClick={() => toggleAnswer(index)}>
                                <p>Q: {faq.title}</p>
                                <img
                                    src={plus}
                                    alt="Toggle Answer"
                                    style={{
                                        transform: visibleAnswers[index] ? 'rotate(45deg)' : 'rotate(0deg)',
                                        transition: 'transform 0.3s ease',
                                        cursor:'pointer'
                                    }}
                                />
                            </div>
                            {visibleAnswers[index] && (
                                <div className="faq-answer">
                                    <p>A: {faq.description}</p>
                                </div>
                            )}
                            <div className='fhr'>
                                <hr />
                            </div>
                        </div>
                    ))}
                </div>

                <div className="fimage">
                    <img src={fimg} alt="FAQ Illustration" />
                </div>
            </div>
        </div>
    );
}