import React, { useState, useEffect } from 'react';
import './Super_Manage_Faq.css';
import arrow from '../Images/arrow.png';
import img1 from '../Images/SuperAdminBody.jpg';

export default function Super_Manage_Faq(props) {
    const [faqs, setFaqs] = useState([]);
    const [showAddForm, setShowAddForm] = useState(false);
    const [newQuestion, setNewQuestion] = useState('');
    const [newAnswer, setNewAnswer] = useState('');
    const [editingId, setEditingId] = useState(null);
    const [editedQuestion, setEditedQuestion] = useState('');
    const [editedAnswer, setEditedAnswer] = useState('');

    const fetchFaqs = async () => {
        try {
            const response = await fetch(`${props.ngrok_url}/api/Content/fetchfaqs`, {
                headers: {
                    'ngrok-skip-browser-warning': 'true'
                }
            });
            const data = await response.json();
            
            const transformedFaqs = data.map(faq => ({
                id: faq.id,
                question: faq.title.toUpperCase(),
                answer: faq.description.split('\n').filter(line => line.trim())
            }));
            
            setFaqs(transformedFaqs);
        } catch (error) {
            console.error('Error fetching FAQs:', error);
        }
    };

    useEffect(() => {
        fetchFaqs();
    }, []);

    const handleAddNew = () => {
        setShowAddForm(true);
    };

    const handleSaveNew = async () => {
        if (newQuestion.trim() && newAnswer.trim()) {
            try {
                const response = await fetch(`${props.ngrok_url}/api/Content/createfaqs`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'ngrok-skip-browser-warning': 'true'
                    },
                    body: JSON.stringify({
                        title: newQuestion,
                        description: newAnswer
                    })
                });

                if (!response.ok) {
                    throw new Error('Failed to create FAQ');
                }

                // Refresh FAQs after successful creation
                await fetchFaqs();

                setNewQuestion('');
                setNewAnswer('');
                setShowAddForm(false);
            } catch (error) {
                console.error('Error creating FAQ:', error);
                alert('Failed to save FAQ. Please try again.');
            }
        }
    };

    const handleCancelAdd = () => {
        setNewQuestion('');
        setNewAnswer('');
        setShowAddForm(false);
    };

    const handleEdit = (faq) => {
        setEditingId(faq.id);
        setEditedQuestion(faq.question);
        setEditedAnswer(faq.answer.join('\n'));
    };

    const handleSaveEdit = async (id) => {
        try {
            const response = await fetch(`${props.ngrok_url}/api/Content/updatefaqs/${id}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'ngrok-skip-browser-warning': 'true'
                },
                body: JSON.stringify({
                    title: editedQuestion,
                    description: editedAnswer
                })
            });

            if (!response.ok) {
                throw new Error('Failed to update FAQ');
            }

            // Refresh FAQs after successful update
            await fetchFaqs();

            setEditingId(null);
        } catch (error) {
            console.error('Error updating FAQ:', error);
            alert('Failed to update FAQ. Please try again.');
        }
    };

    const handleCancelEdit = () => {
        setEditingId(null);
    };

    const handleDelete = async (id) => {
        if (window.confirm('Are you sure you want to delete this FAQ?')) {
            try {
                const response = await fetch(`${props.ngrok_url}/api/Content/deleteFaq/${id}`, {
                    method: 'DELETE',
                    headers: {
                        'ngrok-skip-browser-warning': 'true'
                    }
                });

                if (!response.ok) {
                    throw new Error('Failed to delete FAQ');
                }

                // Refresh FAQs after successful deletion
                await fetchFaqs();
            } catch (error) {
                console.error('Error deleting FAQ:', error);
                alert('Failed to delete FAQ. Please try again.');
            }
        }
    };

    return (
        <div className='s_mange_faq'>
            <div className="s_managefaq_head">
                <img src={arrow} alt="" onClick={() => window.history.back()} />
                <h4>FAQ`s Management</h4>
            </div>

            <div className="s_managefaq_body">
                <div className="s_faq_main">
                    <div className="s_faq_head">
                        <div className="s_faq_h">
                            Main Heading Text:
                        </div>
                        <div className="s_faq_h_text">
                            <h4>For Cricket Rooftop booking system,</h4>
                            <h4>the FAQ`s might include the following points:</h4>
                        </div>
                    </div>

                    <div className="s_faq_body">
                        <div className="s_faq_h">
                            FAQ`s:
                        </div>
                        <div className="s_faq_border">
                            {faqs.map((faq, index) => (
                                <div className="s_faq_body_text" key={faq.id}>
                                    {editingId === faq.id ? (
                                        <>
                                            <div className="s_faq_question">
                                                <input
                                                    type="text"
                                                    value={editedQuestion}
                                                    onChange={(e) => setEditedQuestion(e.target.value)}
                                                    className="s_faq_input"
                                                />
                                            </div>
                                            <div className="s_faq_body_text1">
                                                <textarea
                                                    value={editedAnswer}
                                                    onChange={(e) => setEditedAnswer(e.target.value)}
                                                    className="s_faq_textarea"
                                                />
                                            </div>
                                            <div className="s_faq_buttons">
                                                <button onClick={() => handleSaveEdit(faq.id)} className="s_faq_button save">Save</button>
                                                <button onClick={handleCancelEdit} className="s_faq_button cancel">Cancel</button>
                                            </div>
                                        </>
                                    ) : (
                                        <>
                                            <div className="s_faq_question">
                                                {index + 1}. {faq.question}
                                            </div>
                                            <div className="s_faq_body_text1">
                                                {faq.answer.map((line, i) => (
                                                    <h4 key={i} className="s_faq_answer_line">{line}</h4>
                                                ))}
                                            </div>
                                            <div className="s_faq_buttons">
                                                <button onClick={() => handleEdit(faq)} className="s_faq_button edit">Edit</button>
                                                <button onClick={() => handleDelete(faq.id)} className="s_faq_button delete">Delete</button>
                                            </div>
                                        </>
                                    )}
                                </div>
                            ))}

                            {showAddForm && (
                                <div className="s_faq_body_text">
                                    <div className="s_faq_question">
                                        <input
                                            type="text"
                                            value={newQuestion}
                                            onChange={(e) => setNewQuestion(e.target.value)}
                                            placeholder="Enter new question"
                                            className="s_faq_input"
                                        />
                                    </div>
                                    <div className="s_faq_body_text1">
                                        <textarea
                                            value={newAnswer}
                                            onChange={(e) => setNewAnswer(e.target.value)}
                                            placeholder="Enter answer (separate points with new lines)"
                                            className="s_faq_textarea"
                                        />
                                    </div>
                                    <div className="s_faq_buttons">
                                        <button onClick={handleSaveNew} className="s_faq_button save">Save</button>
                                        <button onClick={handleCancelAdd} className="s_faq_button cancel">Cancel</button>
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                </div>

                <div className="s_managefaq_img">
                    <img src={img1} alt="" />
                </div>
            </div>
            <div className="s_faq_btn">
                <button onClick={handleAddNew} className="s_faq_button add">Add New</button>
            </div>
        </div>
    );
}