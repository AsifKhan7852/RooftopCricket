import React from 'react';
import vsignin from '../Images/vsignin.png';
import './Register_NewPassword.css';

export default function Register_NewPassword() {
    return (
        <div className="container">
            <div className="left-section">
                <img src={vsignin} alt="Player Illustration" className="player-image" />
            </div>
            <div className="right-section">
                <h1 className="heading">Set a new Password</h1>

                <div className="input-container">
                    <p className="subtext">
                        Create a new password. Ensure it differs from previous ones for security
                    </p>
                    <input
                        type="password"
                        placeholder="New Password"
                        className="password-input"
                    />
                    <input
                        type="password"
                        placeholder="Confirm Password"
                        className="password-input"
                    />
                </div>
                <button className="update-button" onClick={() => console.log('Update Password clicked')}>
                    Update Password
                </button>
            </div>
        </div>
    );
}