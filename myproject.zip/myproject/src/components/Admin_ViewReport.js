import React, { useState, useEffect } from 'react';
import './Admin_ViewReport.css';
import arrow from '../Images/arrow.png';
import search from '../Images/search.png';

export default function Admin_ViewReport(props) {
    const [tableData, setTableData] = useState([]);
    const [metrics, setMetrics] = useState({ totalBookings: 0, average: 0, totalRevenue: 0 });
    const [isDropdownOpen, setIsDropdownOpen] = useState(false);
    const [selectedDate, setSelectedDate] = useState('');
    const [reportType, setReportType] = useState('Daily');

    // Fetch customer data based on report type and filter value
    const fetchCustomerData = async (type = null, filterValue = null) => {
        try {
            const adminSignin = JSON.parse(localStorage.getItem('adminSignin'));
            const rooftopId = adminSignin?.rooftops?.[0]?.id || 1;
            let url = `${props.ngrok_url}/api/UsersManagement/customers/byRooftop?status=All&rooftopId=${rooftopId}`;
            if (type === 'Daily' && filterValue) {
                url += `&date=${filterValue}`;
            } else if (type === 'Monthly' && filterValue) {
                url += `&month=${filterValue}`;
            }
            const response = await fetch(url, {
                headers: {
                    'ngrok-skip-browser-warning': 'true'
                }
            });
            const data = await response.json();
            const formattedData = data.map(customer => ({
                customer: customer.name || '',
                phoneno: customer.phoneNo || '',
                successful: customer.successfulBookings || 0,
                canceled: customer.cancelledBookings || 0,
                amountpaid: customer.amountPaid || 0
            }));
            setTableData(formattedData);

            // Calculate metrics only if no filter is applied (initial load or reset)
            if (!type || !filterValue) {
                const sales = formattedData.reduce((sum, row) => sum + (row.successful || 0), 0);
                const totalRevenue = formattedData.reduce((sum, row) => sum + (row.amountpaid || 0), 0);
                const average = sales > 0 ? (totalRevenue / sales).toFixed(2) : 0;
                setMetrics({ totalBookings: sales, average, totalRevenue });
            }
        } catch (error) {
            console.error('Error fetching customer data:', error);
            setTableData([]);
            if (!type || !filterValue) {
                setMetrics({ totalBookings: 0, average: 0, totalRevenue: 0 });
            }
        }
    };

    // Fetch daily report data for summary metrics
    const fetchDailyReport = async (date) => {
        try {
            const adminSignin = JSON.parse(localStorage.getItem('adminSignin'));
            const rooftopId = adminSignin?.rooftops?.[0]?.id || 1;
            const response = await fetch(
                `${props.ngrok_url}/api/Reports/GetDailyReport?rooftopId=${rooftopId}&date=${date}`,
                {
                    headers: {
                        'ngrok-skip-browser-warning': 'true'
                    }
                }
            );
            const data = await response.json();
            if (data.length > 0) {
                const report = data[0];
                setMetrics({
                    totalBookings: report.totalBookings,
                    average: report.dailyAverage,
                    totalRevenue: report.totalRevenue
                });
            } else {
                setMetrics({ totalBookings: 0, average: 0, totalRevenue: 0 });
            }
        } catch (error) {
            console.error('Error fetching daily report:', error);
            setMetrics({ totalBookings: 0, average: 0, totalRevenue: 0 });
        }
    };

    // Fetch monthly report data for summary metrics
    const fetchMonthlyReport = async (month) => {
        try {
            const adminSignin = JSON.parse(localStorage.getItem('adminSignin'));
            const rooftopId = adminSignin?.rooftops?.[0]?.id || 1;
            const response = await fetch(
                `${props.ngrok_url}/api/Reports/GetMonthlyReport?rooftopId=${rooftopId}&month=${month}`,
                {
                    headers: {
                        'ngrok-skip-browser-warning': 'true'
                    }
                }
            );
            const data = await response.json();
            if (data.length > 0) {
                const report = data[0];
                setMetrics({
                    totalBookings: report.totalBookings,
                    average: report.monthlyAverage,
                    totalRevenue: report.totalRevenue
                });
            } else {
                setMetrics({ totalBookings: 0, average: 0, totalRevenue: 0 });
            }
        } catch (error) {
            console.error('Error fetching monthly report:', error);
            setMetrics({ totalBookings: 0, average: 0, totalRevenue: 0 });
        }
    };

    // Fetch all customers on initial load
    useEffect(() => {
        fetchCustomerData();
    }, []);

    // Handle report type change
    const handleReportTypeChange = (type) => {
        setReportType(type);
        setSelectedDate(''); // Clear selected date when switching report type
        setIsDropdownOpen(false);
        fetchCustomerData(); // Reset to all customers
    };

    // Handle search button click
    const handleDateSearch = () => {
        if (selectedDate) {
            if (reportType === 'Daily') {
                fetchCustomerData('Daily', selectedDate);
                fetchDailyReport(selectedDate);
            } else if (reportType === 'Monthly') {
                fetchCustomerData('Monthly', selectedDate);
                fetchMonthlyReport(selectedDate);
            }
        } else {
            console.log('Please select a date or month');
            // Optionally, alert the user to select a date/month
        }
    };

    return (
        <div className='view_report'>
            <div className='view_head'>
                <img src={arrow} alt='Back' />
                <h4>Reports</h4>
            </div>

            <div className="drop-search">
                <div className="viewdrop">
                    <button onClick={() => setIsDropdownOpen(!isDropdownOpen)} className="view_dropbtn">
                        {reportType} ▼
                    </button>
                    {isDropdownOpen && (
                        <div className="view_dropdown-content">
                            <a href="#" onClick={() => handleReportTypeChange('Daily')}>Daily</a>
                            <a href="#" onClick={() => handleReportTypeChange('Monthly')}>Monthly</a>
                        </div>
                    )}
                </div>

                <div className="report_search">
                    {reportType === 'Daily' ? (
                        <input
                            type="date"
                            value={selectedDate}
                            onChange={(e) => setSelectedDate(e.target.value)}
                        />
                    ) : (
                        <input
                            type="month"
                            value={selectedDate}
                            onChange={(e) => setSelectedDate(e.target.value)}
                        />
                    )}
                    <button onClick={handleDateSearch}>
                        <img src={search} alt="Search" />
                    </button>
                </div>
            </div>

            <div className='view_table-container'>
                <table className='view_custom-table'>
                    <thead>
                        <tr>
                            <th>Customer Name</th>
                            <th>Phone No.</th>
                            <th>Successful Booking</th>
                            <th>Canceled Booking</th>
                            <th>Amount Paid</th>
                        </tr>
                    </thead>
                    <tbody>
                        {tableData.map((row, index) => (
                            <tr key={index}>
                                <td>{row.customer}</td>
                                <td>{row.phoneno}</td>
                                <td>{row.successful}</td>
                                <td>{row.canceled}</td>
                                <td>{row.amountpaid}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            <div className="sale_main">
                <div className="sale">
                    <label htmlFor="">Total Booking :</label>
                    <label className='sale1' htmlFor="">{metrics.totalBookings}</label>
                </div>

                <div className="average">
                    <label htmlFor="">Average :</label>
                    <label className='sale1' htmlFor="">{metrics.average}</label>
                </div>

                <div className="revenue">
                    <label htmlFor="">Total Revenue :</label>
                    <label className='sale1' htmlFor="">{metrics.totalRevenue}</label>
                </div>
            </div>
        </div>
    );
}