import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import './Admin_Signup3.css';
import img1 from '../Images/admin_body.png';
import arrow from '../Images/arrow.png';

export default function Admin_Edit_Profile3() {
    const navigate = useNavigate();
    const { state } = useLocation();
    const { adminData, rooftopData, images } = state || {};
    const localData = JSON.parse(localStorage.getItem('adminsignin'));
    const rooftop = localData?.rooftops?.[0] || {};
    const email = localData?.admin?.email || '';
    const token = localData?.token || '';

    const [startTime, setStartTime] = useState(rooftop.startTime || '');
    const [endTime, setEndTime] = useState(rooftop.endTime || '');
    const [pitches, setPitches] = useState(rooftop.numberOfPitches || '');
    const [price, setPrice] = useState(rooftop.pricePerHour || '');

    const handleSubmit = async (e) => {
        e.preventDefault();

        const formData = new FormData();

        // Append Admin data, skip password if empty
        Object.entries(adminData).forEach(([key, value]) => {
            if (key === 'Password' && !value) return;
            formData.append(`Admin.${key}`, value);
        });

        const rooftopPayload = {
            ...rooftopData,
            StartTime: startTime,
            EndTime: endTime,
            NumberOfPitches: pitches,
            PricePerHour: price,
        };

        Object.entries(rooftopPayload).forEach(([key, value]) => {
            formData.append(`Rooftop.${key}`, value);
        });

        if (images && images.length > 0) {
            images.forEach(file => {
                formData.append('Rooftop.Images', file);
            });
        }

        try {
            const res = await fetch(`https://47cf-175-107-226-126.ngrok-free.app/api/RooftopAdmin/updateAdminWithRooftop/${email}`, {
                method: 'PUT', // Switch to POST instead of PUT for FormData support
                headers: {
                    Authorization: `Bearer ${token}`,
                    'ngrok-skip-browser-warning': 'true', // bypass ngrok's warning
                },
                body: formData,
            });

            if (res.ok) {
                alert('Profile updated successfully!');
                navigate('/admin_signup3');
            } else {
                const text = await res.text();
                console.error('Server response:', text);
                alert('Update failed. Try again.');
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Something went wrong.');
        }
    };

    return (
        <div className='admin_signup3'>
            <div className="admin_body_tex_signup3">
                <img src={arrow} alt="back" onClick={() => navigate(-1)} />
                <h2>Schedule & Pricing</h2>
                <form className='admin_form_signup3' onSubmit={handleSubmit}>
                    <label>Time Schedule</label><br />
                    <input value={startTime} onChange={e => setStartTime(e.target.value)} required />
                    <input value={endTime} onChange={e => setEndTime(e.target.value)} required /><br /><br />
                    <label>Number of pitches</label><br />
                    <input type='number' value={pitches} onChange={e => setPitches(e.target.value)} required /><br /><br />
                    <label>Price per hour</label><br />
                    <input value={price} onChange={e => setPrice(e.target.value)} required /><br /><br />
                    <button type='submit'>Update</button>
                </form>
            </div>
            <div className="admin_body_im_signup3">
                <img src={img1} alt="bg" />
            </div>
        </div>
    );
}