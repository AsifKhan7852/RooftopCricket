import React, { useState } from 'react';
import './Super_Signin.css';
import img1 from '../Images/adminbody.jpg';
import arrow from '../Images/arrow.png';

export default function Super_Signin(props) {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');
        
        try {
            const response = await fetch(`${props.ngrok_url}/api/SuperAdmin/login`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'ngrok-skip-browser-warning': 'true'
                },
                body: JSON.stringify({
                    Email: email,
                    Password: password
                })
            });

            const data = await response.json();
            
            if (response.ok) {
                localStorage.setItem('superadmin', data.token);
                window.location.href = '/super_home_page';
            } else {
                setError(data.message || 'Login failed. Please check your credentials.');
            }
        } catch (err) {
            setError('An error occurred. Please try again.');
        }
    };

    return (
        <div className='ssignin'>
            <div className="sbody_im">
                <img src={img1} alt="" />
            </div>
            <div className="sbody_tex">
                <img src={arrow} alt="" />
                <h2>Welcome back!</h2>
                <p>Enter your Credentials to access your account</p>
                {error && <div className="error-message">{error}</div>}
                <form onSubmit={handleSubmit} className='svform'>
                    <label htmlFor="email">Email address or Phone No</label> <br />
                    <input 
                        type="text" 
                        id="email"
                        placeholder='Enter your email address or phone number' 
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        size={55} 
                        required
                    />
                    <br />
                    <div className="password-header">
                        <label htmlFor="password">Password</label>
                        <span className='sforget'>Forgot password?</span>
                    </div>
                 
                    <input 
                        type="password" 
                        id="password"
                        placeholder='Enter your password' 
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        size={55} 
                        required
                    />
                    <br /><br />
                    <button type="submit">Login</button>
                </form>
            </div>
        </div>
    )
}