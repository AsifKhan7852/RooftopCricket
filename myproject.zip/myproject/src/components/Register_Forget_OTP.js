import React, { useState, useRef } from 'react';
import vsignin from '../Images/vsignin.png';
import './Register_Forget_OTP.css';

export default function Register_Forget_OTP() {
  const [code, setCode] = useState(['8', '6', '3', '', '']);
  const inputRefs = useRef([]);

  const handleInputChange = (e, index) => {
    const value = e.target.value;
    if (value.length <= 1) {
      const newCode = [...code];
      newCode[index] = value;
      setCode(newCode);
      if (value && index < 4) {
        inputRefs.current[index + 1].focus();
      }
    }
  };

  const handleKeyDown = (e, index) => {
    if (e.key === 'Backspace' && !code[index] && index > 0) {
      inputRefs.current[index - 1].focus();
    }
  };

  return (
    <div className="container">
      <div className="left-section">
        <img src={vsignin} alt="Player Illustration" className="player-image" />
      </div>
      <div className="right-section">
        <h1 className="heading">Check your Email</h1>
        <p className="subtext">
          We sent a reset link to contact@dsdcode...com <br />enter 5 digit code that mentioned in the email
        </p>
        <div className="input-container">
          {code.map((digit, index) => (
            <input
              key={index}
              type="text"
              maxLength="1"
              value={digit}
              onChange={(e) => handleInputChange(e, index)}
              onKeyDown={(e) => handleKeyDown(e, index)}
              ref={(el) => (inputRefs.current[index] = el)}
              className="otp-input"
            />
          ))}
        </div>
        <button className="verify-button" onClick={() => console.log('Verify Code clicked')}>
          Verify Code
        </button>
        <button className="resend-button" onClick={() => console.log('Resend Code clicked')}>
          Resend Code
        </button>
      </div>
    </div>
  );
}