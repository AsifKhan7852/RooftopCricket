import React, { useEffect, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import './Register_Available_Slots.css';
import arrow from '../Images/arrow.png';
import img1 from '../Images/admin_body.png';
import search from '../Images/search.png';

export default function Register_Available_Slots(props) {
    const [slots, setSlots] = useState([]);
    const [selectedDate, setSelectedDate] = useState('');
    const [startTime, setStartTime] = useState('');
    const [endTime, setEndTime] = useState('');
    
    const navigate = useNavigate();
    const location = useLocation();
    const storedRooftopId = localStorage.getItem("RooftopId") || {};

    // Preserve cart data when coming back
    const [cart, setCart] = useState(location.state?.cart || []);

    const formatDate = (date) => {
        if (!date) return '';
        const [year, month, day] = date.split('-');
        return `${day}-${month}-${year}`;
    };

    // Fetch available slots
    const fetchSlots = async (date = '') => {
        try {
            let url = `${props.ngrok_url}/api/Slots/filterAvailableSlots?rooftopId=${storedRooftopId}`;
            if (date) url += `&date=${encodeURIComponent(formatDate(date))}`;

            console.log("Fetching URL:", url);

            const response = await fetch(url, {
                headers: {
                    'Content-Type': 'application/json',
                    'ngrok-skip-browser-warning': 'true'
                }
            });

            const text = await response.text();
            try {
                const data = JSON.parse(text);
                setSlots(data);
            } catch (jsonError) {
                console.error("API Response Error:", text);
            }
        } catch (error) {
            console.error("Error fetching data:", error);
        }
    };

    // Handle slot search with filters
    const handleSearch = async () => {
        if (!selectedDate || !startTime) {
            alert("Please select a date and start time.");
            return;
        }

        const now = new Date();
        const selectedDateTime = new Date(`${selectedDate}T${startTime}`);

        if (selectedDateTime <= now) {
            alert("Start time must be in the future.");
            return;
        }

        try {
            let url = `${props.ngrok_url}/api/Slots/filterAvailableSlots?rooftopId=${storedRooftopId}`;
            if (selectedDate) url += `&date=${encodeURIComponent(formatDate(selectedDate))}`;
            if (startTime) url += `&startTime=${encodeURIComponent(startTime)}`;
            if (endTime) url += `&endTime=${encodeURIComponent(endTime)}`;

            console.log("Fetching URL (Time Filter):", url);

            const response = await fetch(url, {
                headers: {
                    'Content-Type': 'application/json',
                    'ngrok-skip-browser-warning': 'true'
                }
            });

            const text = await response.text();
            console.log("Raw Response:", text);

            try {
                const data = JSON.parse(text);
                setSlots(data);
            } catch (jsonError) {
                console.error("API Response Error:", text);
            }
        } catch (error) {
            console.error("Error fetching data:", error);
        }
    };

    useEffect(() => {
        fetchSlots(selectedDate);
    }, [selectedDate]);

    // Add slot to cart
    const handleAddToCart = (slotId) => {
        const selectedSlot = slots.find(slot => slot.slotId === slotId);
        if (!selectedSlot || selectedSlot.availableCapacity <= 0) return;

        setSlots(prevSlots =>
            prevSlots.map(slot =>
                slot.slotId === slotId
                    ? { ...slot, availableCapacity: slot.availableCapacity - 1 }
                    : slot
            ).filter(slot => slot.availableCapacity > 0) // Remove slots with availableCapacity = 0
        );

        setCart(prevCart => [...prevCart, {
            slotId: selectedSlot.slotId,
            slotDate: selectedSlot.date,
            startTime: selectedSlot.startTime,
            endTime: selectedSlot.endTime
        }]);
    };

    // Handle navigation back (Preserve cart data)
    const handleBack = () => {
        navigate(-1, { state: { cart } }); // Navigate back with cart data
    };

    // Proceed to Register_Booking_Form with selected slots
    const handleProceed = () => {
        if (cart.length === 0) {
            alert("Please add at least one slot to the cart before proceeding.");
            return;
        }
        navigate('/register_booking_form', { state: { cart } });
    };

    return (
        <div className='register_n_book'>
            <div className="register_avail_head">
                <img src={arrow} alt="Back" onClick={handleBack} style={{ cursor: "pointer" }} />
                <h4>Available Slots</h4>
            </div>

            <div className="register_avail_body">
                <div className="register_avail_text">
                    <div className="register_avail_calender">
                        <input
                            className='register_avail_calender_input'
                            type="date"
                            value={selectedDate}
                            onChange={(e) => setSelectedDate(e.target.value)}
                        />

                        <label>From: </label>
                        <input
                            className='register_avail_calender_input'
                            type="time"
                            value={startTime}
                            onChange={(e) => setStartTime(e.target.value)}
                        />

                        <label>To:</label>
                        <input
                            className='register_avail_calender_input'
                            type="time"
                            value={endTime}
                            onChange={(e) => setEndTime(e.target.value)}
                        />

                        <div className="register_avail_search" onClick={handleSearch}>
                            <img src={search} alt="Search" style={{ pointerEvents: "none" }} />
                        </div>
                    </div>

                    <div className="register_avail_table-container">
                        <table className="register_avail_custom-table">
                            <thead>
                                <tr>
                                    <th>Slot Date</th>
                                    <th>Slot Time</th>
                                    <th>Status</th>
                                    <th>Available Pitches</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                {slots.length > 0 ? (
                                    slots.map((slot) => (
                                        <tr key={slot.slotId}>
                                            <td>{slot.date}</td>
                                            <td>{`${slot.startTime} - ${slot.endTime}`}</td>
                                            <td>{slot.status}</td>
                                            <td>{slot.availableCapacity}</td>
                                            <td>
                                                <button
                                                    className="register_avail_button"
                                                    onClick={() => handleAddToCart(slot.slotId)}
                                                    disabled={slot.availableCapacity === 0}
                                                >
                                                    {slot.availableCapacity > 0 ? "Add to Cart" : "Unavailable"}
                                                </button>
                                            </td>
                                        </tr>
                                    ))
                                ) : (
                                    <tr>
                                        <td colSpan="5">No slots available</td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>
                <div className="register_avail_img">
                    <img src={img1} alt="Decoration" />
                </div>
            </div>

            <div className="register_b_btn">
                <button onClick={handleProceed}>Proceed</button>
            </div>
        </div>
    );
}