import React, { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import './Register_Booking_Form.css';
import arrow from '../Images/arrow.png';
import img1 from '../Images/admin_body.png';

export default function Register_Booking_Form() {
    const navigate = useNavigate();
    const location = useLocation();
    const { cart: initialCart = [] } = location.state || {}; // Slots from Proceed button

    const [cart, setCart] = useState(initialCart);

    // Local Storage se Name aur Phone No uthana
    const storeUser = JSON.parse(localStorage.getItem("User")) || "Unknown";

    const handleBook = () => {
        if (cart.length === 0) {
            alert("Please add at least one slot to the cart before proceeding.");
            return;
        }
        navigate('/register_terms', { state: { cart } }); // Navigate with cart data
    };

    const handleRemove = (index) => {
        const updatedCart = cart.filter((_, i) => i !== index);
        setCart(updatedCart);
    };

    const handleBack = () => {
        navigate('/rooftop_available_slots', { state: { cart } }); // Navigate back with cart data
    };

    return (
        <div className='register_bookform'>
            <div className="register_bookform_head">
                <img src={arrow} alt="Back" onClick={handleBack} style={{ cursor: "pointer" }} />
                <h4>Booking Form</h4>
            </div>
            <div className="selected_slot_heading">
                <h4>Selected Slots:</h4>
            </div>

            <div className="register_bookform_body">
                <div className="register_bookform_text">
                    <div className="register_bookform_table-container">
                        <table className="register_bookform_custom-table">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Time</th>
                                    <th>Name</th>
                                    <th>Phone No</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                {cart.length > 0 ? cart.map((slot, index) => (
                                    <tr key={index}>
                                        <td>{slot.slotDate}</td>
                                        <td>{`${slot.startTime} - ${slot.endTime}`}</td>
                                        <td>{storeUser.Name}</td>
                                        <td>{storeUser.PhoneNo}</td>
                                        <td>
                                            <button className="register_bookform_button" onClick={() => handleRemove(index)}>Remove</button>
                                        </td>
                                    </tr>
                                )) : (
                                    <tr>
                                        <td colSpan="5">No slots selected</td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div className="register_bookform_btn">
                <button onClick={handleBook}>Book Now</button>
            </div>
        </div>
    );
}