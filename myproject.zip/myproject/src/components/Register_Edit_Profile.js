import React, { useState, useEffect } from 'react';
import { useNavigate } from "react-router-dom"; // Import useNavigate for redirection
import './Register_Edit_Profile.css';
import img1 from "../Images/user_signup.png";
import arrow from "../Images/arrow.png";

export default function Register_Edit_Profile(props) {
    const navigate = useNavigate(); // React Router navigation

    const storedUser = JSON.parse(localStorage.getItem("User")) || {};
    const token = storedUser.Token;

    const [name, setName] = useState(storedUser.Name || "");
    const [email, setEmail] = useState(storedUser.Email || "");
    const [phoneNo, setPhoneNo] = useState(storedUser.PhoneNo || "");
    const [password, setPassword] = useState("");
    const [error, setError] = useState("");

    useEffect(() => {
        if (!storedUser.UserId || !token) {
            navigate("/user_signin"); // Redirect if no user found
        }
    }, []);

    const handleUpdate = async (e) => {
        e.preventDefault();

        if (!storedUser.UserId || !token) {
            setError("Authentication error! Please log in again.");
            return;
        }

        const formData = new FormData();
        formData.append("UserId", storedUser.UserId);
        formData.append("Name", name);
        formData.append("Email", email);
        formData.append("PhoneNo", phoneNo);
        formData.append("Password", password);

        try {
            const response = await fetch(
                `${props.ngrok_url}/api/RegisteredUser/updateprofile/${storedUser.UserId}`,
                {
                    method: "PUT",
                    headers: {
                        "Authorization": `Bearer ${token}`,
                    },
                    body: formData,
                }
            );

            const data = await response.json();

            if (response.ok) {
                alert("Profile Updated Successfully!");
                localStorage.setItem("User", JSON.stringify({
                    ...storedUser,
                    Name: name,
                    Email: email,
                    PhoneNo: phoneNo,
                    Token: token
                }));
                console.log("Redirecting to Register_Home_Page...");
                navigate("/Register_Home_Page"); // ✅ Correct redirection
            } else {
                setError(data.message || "Update failed. Try again.");
            }
        } catch (err) {
            setError("Error connecting to server");
        }
    };

    return (
        <div className="visitor_signup">
            <div className="visitor_body_tex_signup">
                <img src={arrow} alt="Arrow" />
                <h2>Update Your Profile</h2>
                <form className="visitor_form_signup" onSubmit={handleUpdate}>
                    <label>Name</label><br />
                    <input
                        type="text"
                        placeholder="Enter your name"
                        size={55}
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        required
                    /><br /><br />

                    <label>Email address</label><br />
                    <input
                        type="email"
                        placeholder="Enter your email address"
                        size={55}
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                    /><br /><br />

                    <label>Phone number</label><br />
                    <input
                        type="text"
                        placeholder="Enter your phone number"
                        size={55}
                        value={phoneNo}
                        onChange={(e) => setPhoneNo(e.target.value)}
                        required
                    /><br /><br />

                    <label>Password</label><br />
                    <input
                        type="password"
                        placeholder="Enter new password"
                        size={55}
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                    /><br /><br />

                    <button type="submit">Update</button>
                </form>

                {error && <p style={{ color: "red" }}>{error}</p>}
            </div>

            <div className="vistor_body_im_signup">
                <img src={img1} alt="Signup" />
            </div>
        </div>
    );
}
