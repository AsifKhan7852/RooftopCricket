import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom'; // Import useNavigate for redirection
import './Registered_Home_Page.css';
import img2 from '../Images/nav_back.png';
import img3 from '../Images/registerbodyimage.png';
import img4 from '../Images/bottom-bar2.png';
import img5 from '../Images/bottom-bar1.png';

export default function Registered_Home_Page(props) {
    const [isDropdownOpen, setIsDropdownOpen] = useState(false);
    const navigate = useNavigate();

    const storedUser = JSON.parse(localStorage.getItem("User")) || {};
    const token = storedUser.Token;

    // Function to handle account deletion
    const handleDeleteAccount = async () => {
        if (!storedUser.UserId || !token) {
            alert("User not found! Please log in again.");
            navigate("/user_signin");
            return;
        }

        const confirmDelete = window.confirm("Are you sure you want to delete your account? This action is irreversible.");
        if (!confirmDelete) return;

        try {
            const response = await fetch(`${props.ngrok_url}/api/RegisteredUser/delete/${storedUser.UserId}`, {
                method: "DELETE",
                headers: {
                    "Authorization": `Bearer ${token}`,
                },
            });

            if (response.ok) {
                alert("Account deleted successfully!");
                localStorage.removeItem("User"); // Remove user from localStorage
                navigate("/"); // Redirect to visitor home page
            } else {
                const data = await response.json();
                alert(data.message || "Failed to delete account. Please try again.");
            }
        } catch (error) {
            alert("Error connecting to server. Please try again later.");
        }
    };

    // Function to handle logout
    const handleLogout = () => {
        localStorage.removeItem("User"); // Clear user data
        navigate("/user_signin"); // Redirect to login page
    };

    // Function to open WhatsApp chat
    const openWhatsAppChat = () => {
        const phoneNumber = '+923015317852'; // WhatsApp number
        const url = `https://wa.me/${phoneNumber}`; // WhatsApp URL
        window.open(url, '_blank'); // Open in a new tab
    };

    return (
        <div className='rmain'>
            <div className="register_nav">
                <div className='rnav_text'>
                    <a href='/book_rooftop'>Book Roof-Top</a>
                    <a href='/mybooking'>My Bookings</a>
                    <a href='/faq'>View FAQ Sec</a>
                    <a href='/aboutus'>About us</a>
                    <a onClick={openWhatsAppChat} style={{ cursor: 'pointer' }}>Help Center</a>

                    {/* Dropdown for Account Setting */}
                    <div className="dropdown">
                        <button onClick={() => setIsDropdownOpen(!isDropdownOpen)} className="dropbtn">
                            Account Setting ▼
                        </button>
                        {isDropdownOpen && (
                            <div className="dropdown-content">
                                <a href="/user_edit_profile">Edit Profile</a>
                                <a onClick={handleDeleteAccount} className="dropdown-delete">Delete Account</a>
                                <a onClick={handleLogout} className="dropdown-logout">Logout</a>
                            </div>
                        )}
                    </div>
                </div>
                <img src={img2} alt="" />
            </div>

            <div className="rbody">
                <div className="rbody_text">
                    <p>Game On, Above The City</p>
                    <p className='rexplore'>Rooftop Cricket</p>
                </div>
                <div className="rbody_img">
                    <img src={img3} alt="" />
                </div>
            </div>

            <div className="rvisitor_footor">
                <img src={img4} alt="" />
                <img src={img5} alt="" />
            </div>
        </div>
    );
}