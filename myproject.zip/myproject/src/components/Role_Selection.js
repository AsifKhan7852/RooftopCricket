import React from 'react'
// import { Link } from 'react-router-dom'
import './Role_Selection.css'
import arrow from '../Images/arrow.png'
import back from '../Images/signinup.png'
import rolepic from '../Images/rolepic.png'


export default function Role_Selection() {
    return (
        <div className='s_role'>
            <div className='s_arrow'>
                <img src={arrow} alt="" />
            </div>
            <div className="s_select">
                <div className="s_heading">
                    <h4>Select role for Signin: </h4>
                </div>
                <div className="s_role_selection">
                    <img src={back} alt="" />
                    <a href='/user_signin'>User</a>
                    <img src={back} alt="" />
                    <a href='/admin_signup3'>Admin</a>
                    <img src={back} alt="" />
                    <a href='super_signin'>Super Admin</a>
                </div>
                <div className="s_rolepic">
                <img src={rolepic} alt="" />
                </div>
            </div>
        </div>
    )
}
